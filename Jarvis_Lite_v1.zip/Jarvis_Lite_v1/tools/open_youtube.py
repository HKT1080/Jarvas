﻿import sys
import urllib.parse
import webbrowser

query = " ".join(sys.argv[1:]).strip()
if query:
    url = "https://www.youtube.com/results?search_query=" + urllib.parse.quote(query)
    webbrowser.open_new_tab(url)
    print(f"Đã mở YouTube và tìm: {query}")
else:
    webbrowser.open_new_tab("https://www.youtube.com")
    print("Đã mở YouTube lên rồi nha mày!")

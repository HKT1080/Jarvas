﻿import os
import subprocess
import sys

query = " ".join(sys.argv[1:]).strip().lower()
if not query:
    print("Mày muốn tìm file tên gì? Ví dụ: 'Tìm file báo cáo'.")
    sys.exit(0)

home = os.path.expanduser("~")
search_dirs = [
    os.path.join(home, "Desktop"),
    os.path.join(home, "Downloads"),
    os.path.join(home, "Documents"),
    os.getcwd(),
]

matches = []
SKIP = {"venv", ".venv", "node_modules", ".git", "__pycache__", "AppData"}

for base in search_dirs:
    if not os.path.isdir(base):
        continue
    for root, dirs, files in os.walk(base):
        dirs[:] = [d for d in dirs if d not in SKIP and not d.startswith(".")]
        for fn in files:
            if query in fn.lower():
                matches.append(os.path.join(root, fn))
                if len(matches) >= 8:
                    break
        if len(matches) >= 8:
            break

if not matches:
    print(f"Không tìm thấy file nào có chữ '{query}' trong Desktop, Downloads, Documents.")
    sys.exit(0)

try:
    subprocess.Popen(["explorer", "/select,", matches[0]], creationflags=0x08000000)
except Exception:
    pass

lines = [f"- {os.path.basename(p)}  ({os.path.dirname(p)})" for p in matches[:5]]
print(f"🔎 Tìm thấy {len(matches)} file (đã mở sẵn file đầu tiên):\n" + "\n".join(lines))

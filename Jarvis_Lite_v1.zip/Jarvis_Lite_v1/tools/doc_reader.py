﻿import os
import sys

arg = " ".join(sys.argv[1:]).strip()
if not arg:
    print("🧠 Đưa tao đường dẫn file (.pdf, .docx, .txt) để tao đọc nha! Ví dụ: 'đọc file D:\\tailieu.pdf'.")
    sys.exit(0)

# Tách đường dẫn file và từ khóa tìm kiếm (nếu có dấu |)
if "|" in arg:
    path, kw = [x.strip() for x in arg.split("|", 1)]
else:
    path, kw = arg, ""

path = path.strip('"').strip("'")
if not os.path.isfile(path):
    print(f"Không tìm thấy file: {path}")
    sys.exit(0)

ext = os.path.splitext(path)[1].lower()
text = ""

try:
    if ext == ".pdf":
        from pypdf import PdfReader
        reader = PdfReader(path)
        text = "\n".join((p.extract_text() or "") for p in reader.pages)
    elif ext == ".docx":
        import docx
        d = docx.Document(path)
        text = "\n".join(p.text for p in d.paragraphs if p.text.strip())
    else:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            text = f.read()
except Exception as e:
    print(f"Lỗi đọc file: {e}")
    sys.exit(0)

text = text.strip()
if not text:
    print("File này trống hoặc là file PDF dạng ảnh scan (không có lớp chữ).")
    sys.exit(0)

if kw:
    hits = [line.strip() for line in text.splitlines() if kw.lower() in line.lower()]
    if hits:
        print(f"🔎 Tìm thấy {len(hits)} đoạn chứa '{kw}' trong {os.path.basename(path)}:\n" + "\n".join(f"• {h[:200]}" for h in hits[:8]))
    else:
        print(f"Không tìm thấy từ khóa '{kw}' trong {os.path.basename(path)}.")
else:
    print(f"🧠 Nội dung trích xuất từ {os.path.basename(path)} ({len(text)} ký tự):\n{text[:2500]}")

﻿import os
import subprocess
import sys
import tempfile
import urllib.parse
import requests

data = " ".join(sys.argv[1:]).strip()
if not data:
    res = subprocess.run(
        ["powershell", "-NoProfile", "-Command", "Get-Clipboard"],
        capture_output=True, text=True, encoding="utf-8", errors="replace",
        creationflags=0x08000000,
    )
    data = (res.stdout or "").strip()

if not data:
    print("Không có nội dung để tạo mã QR! Mày copy link hoặc chữ rồi gọi tao nha.")
    sys.exit(0)

try:
    url = f"https://api.qrserver.com/v1/create-qr-code/?size=420x420&data={urllib.parse.quote(data[:900])}"
    r = requests.get(url, timeout=10)
    r.raise_for_status()
    out_path = os.path.join(tempfile.gettempdir(), "jarvis_qr.png")
    with open(out_path, "wb") as f:
        f.write(r.content)
    os.startfile(out_path)
    print(f"📱 Đã tạo mã QR cho '{data[:60]}' và mở sẵn trên màn hình cho mày quét rồi đó!")
except Exception as e:
    print(f"Lỗi tạo mã QR: {e}")

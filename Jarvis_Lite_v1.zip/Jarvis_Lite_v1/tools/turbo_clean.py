﻿import os
import shutil
import subprocess

freed_bytes = 0
targets = [
    os.environ.get("TEMP", ""),
    r"C:\Windows\Temp",
]

for folder in targets:
    if not folder or not os.path.isdir(folder):
        continue
    for item in os.listdir(folder):
        p = os.path.join(folder, item)
        try:
            if os.path.isfile(p) or os.path.islink(p):
                sz = os.path.getsize(p)
                os.remove(p)
                freed_bytes += sz
            elif os.path.isdir(p):
                sz = sum(
                    os.path.getsize(os.path.join(dp, fn))
                    for dp, _, fns in os.walk(p)
                    for fn in fns
                    if os.path.exists(os.path.join(dp, fn))
                )
                shutil.rmtree(p, ignore_errors=True)
                freed_bytes += sz
        except Exception:
            pass

# Dọn sạch Thùng rác (Recycle Bin)
try:
    subprocess.run(
        ["powershell", "-NoProfile", "-Command", "Clear-RecycleBin -Force -ErrorAction SilentlyContinue"],
        creationflags=0x08000000,
        timeout=15,
    )
except Exception:
    pass

mb = freed_bytes / (1024 * 1024)
print(f"🧹 Đã quét dọn file tạm & Thùng rác! Giải phóng ~{mb:.1f} MB cho máy.")

﻿import ctypes
import psutil

psapi = ctypes.windll.psapi
kernel32 = ctypes.windll.kernel32
PROCESS_SET_QUOTA = 0x0100
PROCESS_QUERY_INFORMATION = 0x0400

before = psutil.virtual_memory().percent
trimmed = 0

for p in psutil.process_iter(["pid"]):
    try:
        h = kernel32.OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_SET_QUOTA, False, p.info["pid"])
        if h:
            if psapi.EmptyWorkingSet(h):
                trimmed += 1
            kernel32.CloseHandle(h)
    except Exception:
        pass

after = psutil.virtual_memory().percent
diff = max(0.0, before - after)
print(f"⚡ Đã dọn bộ nhớ đệm cho {trimmed} tiến trình! RAM giảm từ {before:.1f}% xuống {after:.1f}% (giải phóng ~{diff:.1f}%).")

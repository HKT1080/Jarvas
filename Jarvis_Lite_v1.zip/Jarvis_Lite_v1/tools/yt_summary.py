﻿import re
import subprocess
import sys
from youtube_transcript_api import YouTubeTranscriptApi

arg = " ".join(sys.argv[1:]).strip()
if "youtu" not in arg:
    res = subprocess.run(["powershell", "-NoProfile", "-Command", "Get-Clipboard"], capture_output=True, text=True)
    arg = (res.stdout or "").strip()

m = re.search(r"(?:v=|youtu\.be/|shorts/)([A-Za-z0-9_-]{11})", arg)
if not m:
    print("Mày chưa copy link YouTube nào hết! Copy link đi rồi gọi tao lại nha.")
    sys.exit(0)

vid = m.group(1)
try:
    try:
        data = YouTubeTranscriptApi().fetch(vid, languages=["vi", "en"])
        text = " ".join(getattr(x, "text", str(x)) for x in data)
    except Exception:
        data = YouTubeTranscriptApi.get_transcript(vid, languages=["vi", "en"])
        text = " ".join(x["text"] for x in data)
    text = re.sub(r"\s+", " ", text).strip()
    print(f"[Nội dung phụ đề YouTube ({vid})]:\n{text[:2500]}")
except Exception as e:
    print(f"Video này không có phụ đề hoặc bị chặn rồi mày ơi: {e}")

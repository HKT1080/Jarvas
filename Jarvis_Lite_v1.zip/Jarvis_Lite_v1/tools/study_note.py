﻿import datetime
import os
import subprocess
import sys
from PIL import ImageGrab

os.makedirs("notes", exist_ok=True)
today = datetime.date.today().isoformat()
now_str = datetime.datetime.now().strftime("%H:%M:%S")
md_path = os.path.join("notes", f"{today}.md")

content = " ".join(sys.argv[1:]).strip()
if not content:
    res = subprocess.run(["powershell", "-NoProfile", "-Command", "Get-Clipboard"], capture_output=True, text=True, encoding="utf-8", errors="replace", creationflags=0x08000000)
    content = (res.stdout or "").strip()

img_name = f"snap_{datetime.datetime.now().strftime('%H%M%S')}.png"
img_path = os.path.join("notes", img_name)
ImageGrab.grab().save(img_path)

entry = f"\n## [{now_str}] Ghi chú nhanh\n"
if content:
    entry += f"{content}\n"
entry += f"![Ảnh màn hình]({img_name})\n"

with open(md_path, "a", encoding="utf-8") as f:
    f.write(entry)

print(f"📓 Đã lưu ghi chú + ảnh màn hình vào notes/{today}.md lúc {now_str}!")

﻿import subprocess
import sys
import urllib.parse
import requests

arg = " ".join(sys.argv[1:]).strip().lower()
target_lang = "en" if any(k in arg for k in ("sang anh", "tiếng anh", "english", "to en")) else "vi"

res = subprocess.run(
    ["powershell", "-NoProfile", "-Command", "Get-Clipboard"],
    capture_output=True, text=True, encoding="utf-8", errors="replace",
    creationflags=0x08000000,
)
text = (res.stdout or "").strip()

if not text:
    print("Clipboard đang trống! Mày bôi đen đoạn cần dịch rồi Ctrl+C đi xong gọi tao.")
    sys.exit(0)

try:
    url = f"https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl={target_lang}&dt=t&q={urllib.parse.quote(text[:3000])}"
    r = requests.get(url, timeout=8)
    data = r.json()
    translated = "".join(part[0] for part in data[0] if part and part[0]).strip()
    if translated:
        subprocess.run(
            ["powershell", "-NoProfile", "-Command", "Set-Clipboard -Value $input"],
            input=translated, text=True, encoding="utf-8",
            creationflags=0x08000000,
        )
        print(f"🌐 Bản dịch ({target_lang.upper()}) — đã chép sẵn vào Clipboard:\n{translated[:1200]}")
    else:
        print("Không dịch được đoạn này mày ơi.")
except Exception as e:
    print(f"Lỗi dịch thuật: {e}")

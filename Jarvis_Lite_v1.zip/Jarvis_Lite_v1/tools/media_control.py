﻿import ctypes, sys, time

user32 = ctypes.windll.user32
VK = {"mute": 0xAD, "down": 0xAE, "up": 0xAF, "next": 0xB0, "prev": 0xB1, "play": 0xB3}

def press(vk, times=1):
    for _ in range(times):
        user32.keybd_event(vk, 0, 0, 0)
        user32.keybd_event(vk, 0, 2, 0)
        time.sleep(0.04)

cmd = " ".join(sys.argv[1:]).strip().lower()
if any(k in cmd for k in ["tắt tiếng", "im lặng", "mute", "bật tiếng"]):
    press(VK["mute"], 1); print("Đã bật/tắt tiếng hệ thống rồi nha mày!")
elif any(k in cmd for k in ["tăng", "to lên", "up"]):
    press(VK["up"], 6); print("Đã tăng âm lượng lên rồi!")
elif any(k in cmd for k in ["giảm", "nhỏ lại", "down"]):
    press(VK["down"], 6); print("Đã giảm âm lượng xuống rồi!")
elif any(k in cmd for k in ["qua bài", "tiếp", "next"]):
    press(VK["next"], 1); print("Đã chuyển sang bài tiếp theo!")
elif any(k in cmd for k in ["lùi", "trước", "prev", "back"]):
    press(VK["prev"], 1); print("Đã quay lại bài trước!")
elif any(k in cmd for k in ["dừng", "phát", "pause", "play", "tạm dừng"]):
    press(VK["play"], 1); print("Đã dừng/phát nhạc rồi nha mày!")
else:
    print("Chưa rõ lệnh media, mày nói: tăng/giảm/tắt tiếng, dừng nhạc, qua bài nha.")

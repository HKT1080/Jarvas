﻿import datetime
import re
import xml.etree.ElementTree as ET
import psutil
import requests

now = datetime.datetime.now().strftime("%H:%M ngày %d/%m/%Y")
parts = [f"Bây giờ là {now}."]

# Thời tiết TP.HCM
try:
    r = requests.get("https://wttr.in/Ho+Chi+Minh?format=%C,+%t,+độ+ẩm+%h&lang=vi", timeout=5)
    if r.ok and r.text.strip():
        parts.append(f"Thời tiết Sài Gòn hiện tại: {r.text.strip()}.")
except Exception:
    pass

# Tình trạng máy
ram = psutil.virtual_memory().percent
disk = psutil.disk_usage("C:\\").free / (1024 ** 3)
bat = psutil.sensors_battery()
bat_txt = f", pin còn {bat.percent}%" if bat else ""
parts.append(f"Máy đang dùng {ram}% RAM, ổ C còn trống {disk:.1f} GB{bat_txt}.")

# 3 tin nóng Việt Nam
try:
    r = requests.get("https://news.google.com/rss?hl=vi&gl=VN&ceid=VN:vi", timeout=5)
    root = ET.fromstring(r.content)
    titles = [re.sub(r" - .*$", "", it.findtext("title", "")) for it in root.findall(".//item")[:3]]
    if titles:
        parts.append("Điểm tin nóng hôm nay:\n- " + "\n- ".join(titles))
except Exception:
    pass

print("\n".join(parts))

import shutil

for drive in ['C:/', 'D:/']:
    try:
        total, used, free = shutil.disk_usage(drive)
        free_gb = free // (2**30)
        total_gb = total // (2**30)
        print(f'?ĩa {drive}: Tr?ng {free_gb} GB trn t?ng s? {total_gb} GB')
    except Exception:
        print(f'Khng tm th?y ho?c khng truy c?p ???c ?ĩa {drive}')

@echo off
chcp 65001 >nul
title Cai dat JARVIS LITE v1.0
echo ============================================================
echo        CAI DAT TU DONG JARVIS LITE v1.0 (WINDOWS)
echo ============================================================
echo.

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [LOI] May ban chua cai Python 3.10+!
    echo Hay tai Python tai: https://www.python.org/downloads/
    echo LUU Y QUAN TRONG: Nho tick chon "Add Python to PATH" khi cai!
    pause
    exit /b 1
)

echo [1/3] Dang tao moi truong ao (venv)...
if not exist "venv" python -m venv venv

echo [2/3] Dang cai dat cac thu vien nhe (~1-2 phut)...
venv\Scripts\python.exe -m pip install --upgrade pip -q
venv\Scripts\pip.exe install -r requirements_lite.txt

echo [3/3] Hoan tat cai dat!
echo.
echo ============================================================
echo   XONG! Bam dup vao file "start_jarvis.vbs" de mo Jarvis!
echo   (Xem them file HUONG_DAN_SU_DUNG.txt neu can ho tro)
echo ============================================================
pause

﻿# 🌌 Jarvis Lite v1.0 — Trợ Lý AI Thông Minh Cho Windows

**Jarvis Lite** là phiên bản gọn nhẹ, an toàn và thân thiện dành cho mọi người dùng Windows (văn phòng, sinh viên, lập trình viên). Giao diện Dark-Glass hiện đại, cài đặt 1-click, bảo mật API Key cục bộ bằng **Windows DPAPI**.

## ✨ Tính năng nổi bật ở v1.0
- **👁️ Hiểu ý nửa lời (Ambient & Clipboard Context):** Tự biết ứng dụng bạn đang mở và đoạn chữ vừa `Ctrl+C`. Chỉ cần hỏi *"dịch đoạn vừa copy"* hay *"tóm tắt trang này"*.
- **💬 Giao diện Flagship Dark-Glass:** Hiển thị đẹp Markdown, bảng biểu, khối Code có nút Copy 1-click, hỗ trợ **kéo-thả ảnh** và **nhập giọng nói tiếng Việt**.
- **⏰ Nhắc việc chủ động:** Hẹn giờ bằng câu nói tự nhiên (*"15 phút nữa nhắc mình họp"*), tới giờ tự bật thông báo và đọc ra loa.
- **🧬 Trí nhớ dài hạn cục bộ:** Ghi nhớ sở thích/thông tin quan trọng và tự cập nhật khi có thay đổi.
- **🧰 12+ Công cụ dân dụng an toàn:** Thời tiết & tìm web live, tóm tắt YouTube, đọc PDF/Word, dịch nhanh, tạo mã QR, mở ứng dụng/file nhanh, kiểm tra ổ đĩa/RAM, dọn rác tạm.
- **🔐 An toàn tuyệt đối:** API Key được mã hóa bằng Windows DPAPI trên máy người dùng; bản Lite không thực thi lệnh hệ thống ẩn.

## 🚀 Cài đặt nhanh (1-Click)
1. Tải mã nguồn về máy (hoặc `git clone`).
2. Chạy **`install.bat`** để tự động cài đặt môi trường nhẹ (~1–2 phút).
3. Chạy **`start_jarvis.vbs`** và làm theo bảng **Thiết Lập Lần Đầu** (dán Google Gemini API Key miễn phí).

> Xem chi tiết các lệnh mẫu và xử lý lỗi tại file [`HUONG_DAN_SU_DUNG.txt`](./HUONG_DAN_SU_DUNG.txt).

## 🗺️ Lộ trình cập nhật (Roadmap)
- **v1.2:** Đồng bộ & điều khiển PC từ xa qua Telegram (chế độ an toàn).
- **v1.5:** Điều khiển không chạm bằng Cử chỉ tay (Air Gesture Lite) & Nói chuyện liên tục.
- **v2.0 Pro:** Bảo mật sinh trắc khuôn mặt 3D, Visual OS Agent tự thao tác chuột/phím & Tự tiến hóa kỹ năng.

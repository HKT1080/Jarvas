﻿import json
import os
import re
import tempfile
import time
import winreg

os.makedirs("memory", exist_ok=True)
ARTIFACT_FILE = os.path.join("memory", "recent_artifacts.json")
USER_EXT = (
    ".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif",
    ".pdf", ".docx", ".doc", ".xlsx", ".csv", ".txt", ".md",
    ".mp4", ".mp3", ".wav", ".zip", ".html",
)
IMG_EXT = (".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif")
IGNORE_NAMES = {
    "recent_artifacts.json", "jarvis_memory.json", "clipboard_history.json",
    "focus_stats.json", "jarvis_voice.mp3",
}


def _shell_folder(name: str) -> str:
    try:
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders",
        )
        val, _ = winreg.QueryValueEx(key, name)
        winreg.CloseKey(key)
        return os.path.expandvars(val)
    except Exception:
        return ""


def _watch_dirs(include_temp: bool = True) -> list:
    home = os.path.expanduser("~")
    cands = [
        _shell_folder("Desktop"),
        os.path.join(home, "Desktop"),
        os.path.join(home, "OneDrive", "Desktop"),
        _shell_folder("{374DE290-123F-4565-9164-39C4925E467B}"),
        os.path.join(home, "Downloads"),
        _shell_folder("My Pictures"),
        os.path.join(home, "Pictures"),
        os.path.join(home, "OneDrive", "Pictures"),
        os.getcwd(),
    ]
    if include_temp:
        cands.append(tempfile.gettempdir())
    out = []
    seen = set()
    for d in cands:
        if d and os.path.isdir(d):
            norm = os.path.normcase(os.path.abspath(d))
            if norm not in seen:
                seen.add(norm)
                out.append(os.path.abspath(d))
    return out


def snapshot_files() -> dict:
    snap = {}
    tmp_dir = os.path.normcase(os.path.abspath(tempfile.gettempdir()))
    for d in _watch_dirs(include_temp=True):
        is_tmp = os.path.normcase(d) == tmp_dir
        try:
            with os.scandir(d) as it:
                for entry in it:
                    if not entry.is_file():
                        continue
                    low = entry.name.lower()
                    if low in IGNORE_NAMES:
                        continue
                    if is_tmp and not low.endswith(USER_EXT):
                        continue
                    if not is_tmp and low.endswith((".pyc", ".pid", ".tmp", ".log", ".bak", ".lnk", ".ini")):
                        continue
                    snap[entry.path] = entry.stat().st_mtime
        except Exception:
            pass
    return snap


def detect_new_files(before: dict, tool_output: str = "") -> list:
    after = snapshot_files()
    found = []
    for fp, mt in after.items():
        if fp not in before or mt > before[fp] + 0.3:
            found.append(fp)

    for m in re.findall(r'[A-Za-z]:\\[^\n\r"\'<>|*?;]+', tool_output or ""):
        cand = m.strip().rstrip(".,)!]")
        if os.path.isfile(cand) and cand not in found:
            found.append(cand)

    found.sort(key=lambda p: os.path.getmtime(p) if os.path.exists(p) else 0, reverse=True)
    return found[:6]


class WorkingMemory:
    def __init__(self):
        self.data = self._load()

    def _load(self):
        if os.path.exists(ARTIFACT_FILE):
            try:
                return json.load(open(ARTIFACT_FILE, "r", encoding="utf-8-sig"))
            except Exception:
                pass
        return {"files": [], "actions": []}

    def _save(self):
        with open(ARTIFACT_FILE, "w", encoding="utf-8") as f:
            json.dump(self.data, f, ensure_ascii=False, indent=2)

    def record(self, tool_name: str, args: str, output: str, new_files: list):
        ts = time.strftime("%H:%M:%S")
        for fp in new_files:
            self.data["files"] = [x for x in self.data["files"] if x.get("path") != fp]
            self.data["files"].append({"time": ts, "path": fp, "from": tool_name})
        self.data["files"] = self.data["files"][-10:]

        self.data["actions"].append({
            "time": ts,
            "tool": tool_name,
            "args": (args or "")[:120],
            "result": (output or "")[:350],
            "files": new_files,
        })
        self.data["actions"] = self.data["actions"][-6:]
        self._save()

    def get_latest_file(self) -> str:
        for item in reversed(self.data.get("files", [])):
            if os.path.isfile(item.get("path", "")):
                return item["path"]
        return ""

    def find_latest_real_file(self, hint: str = "") -> str:
        low_h = (hint or "").lower()
        want_img = any(k in low_h for k in ("ảnh", "anh", "hình", "hinh", "image", "photo", "qr", "png", "jpg"))
        want_qr = "qr" in low_h

        # 1. Ưu tiên file mới ghi nhận trong sổ WorkingMemory
        for item in reversed(self.data.get("files", [])):
            fp = item.get("path", "")
            if not os.path.isfile(fp):
                continue
            if want_qr and "qr" not in os.path.basename(fp).lower():
                continue
            if want_img and not fp.lower().endswith(IMG_EXT):
                continue
            return fp

        # 2. Fallback: Tự quét thẳng Desktop thật, OneDrive, Downloads, Pictures, cwd và Temp
        cands = []
        tmp_dir = os.path.normcase(os.path.abspath(tempfile.gettempdir()))
        now = time.time()

        for d in _watch_dirs(include_temp=True):
            is_tmp = os.path.normcase(d) == tmp_dir
            try:
                with os.scandir(d) as it:
                    for entry in it:
                        if not entry.is_file():
                            continue
                        low = entry.name.lower()
                        if low in IGNORE_NAMES or not low.endswith(USER_EXT):
                            continue
                        st = entry.stat()
                        # Trong Temp chỉ lấy file của Jarvis/QR hoặc mới tạo trong 30 phút
                        if is_tmp and not ("jarvis" in low or "qr" in low or (now - st.st_mtime < 1800)):
                            continue
                        if want_qr and "qr" not in low:
                            continue
                        if want_img and not low.endswith(IMG_EXT):
                            continue
                        cands.append((st.st_mtime, entry.path))
            except Exception:
                pass

        if cands:
            cands.sort(key=lambda x: x[0], reverse=True)
            return cands[0][1]

        return self.get_latest_file()

    def get_prompt_text(self) -> str:
        lines = []
        valid_files = [f for f in self.data.get("files", []) if os.path.isfile(f.get("path", ""))]
        if valid_files:
            lines.append("Các file vừa tạo/thao tác gần đây (mới nhất ở dưới cùng):")
            for f in valid_files[-5:]:
                lines.append(f"  - [{f['time']}] {f['path']} (từ {f['from']})")
        if self.data.get("actions"):
            lines.append("Kết quả các hành động vừa chạy:")
            for a in self.data["actions"][-3:]:
                lines.append(f"  - [{a['time']}] {a['tool']}: {a['result'][:180]}")
        return "\n".join(lines) if lines else "(Chưa có file gần đây trong phiên này - nếu người dùng đòi mở/gửi ảnh hoặc file gần nhất, vẫn cứ gọi file_pilot để tự quét ổ cứng)"

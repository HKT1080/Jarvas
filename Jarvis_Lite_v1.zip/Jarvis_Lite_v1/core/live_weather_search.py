﻿import html
import json
import re
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"

WMO_VI = {
    0: "Trời quang mây tạnh",
    1: "Trời nắng nhẹ, ít mây",
    2: "Có mây rải rác",
    3: "Trời nhiều mây, âm u",
    45: "Có sương mù",
    48: "Sương mù dày",
    51: "Mưa phùn nhẹ",
    53: "Mưa phùn vừa",
    55: "Mưa phùn dày",
    61: "Mưa nhỏ",
    63: "Mưa vừa",
    65: "Mưa to",
    80: "Mưa rào nhẹ",
    81: "Mưa rào vừa",
    82: "Mưa rào to",
    95: "Có mưa dông, sấm sét",
    96: "Mưa dông kèm gió giật/mưa đá nhẹ",
    99: "Mưa dông rất mạnh",
}

WEATHER_KEYWORDS = (
    "thời tiết", "thoi tiet", "nhiệt độ", "nhiet do", "mấy độ", "may do",
    "có mưa không", "co mua khong", "trời mưa", "troi mua", "dự báo thời tiết",
    "ngoài trời", "weather", "temperature", "forecast",
)


def is_weather_query(q: str) -> bool:
    low = (q or "").lower()
    return any(k in low for k in WEATHER_KEYWORDS)


def _http_get_json(url: str, timeout: int = 10) -> dict | list | None:
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", errors="replace"))


def _extract_city(query: str) -> str:
    s = (query or "").strip()
    s = re.sub(
        r"(?i)\b(dự báo|du bao|thời tiết|thoi tiet|nhiệt độ|nhiet do|hôm nay|hom nay|ngày mai|ngay mai|"
        r"bây giờ|bay gio|hiện tại|hien tai|ngoài trời|ngoai troi|có mưa không|co mua khong|mấy độ|may do|"
        r"như thế nào|nhu the nao|thế nào|the nao|ra sao|xem giúp|cho tao|xem|giùm|cho|biết|hỏi|ở|tại|khu vực|"
        r"thành phố|tp\.?|tỉnh|weather|forecast|in|at|today|now|please)\b",
        " ",
        s,
    )
    s = re.sub(r"[?!.,:;\"'()]+", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    if len(s) < 2 or s.lower() in ("việt nam", "viet nam", "vietnam", "đây", "day", "chỗ tao", "cho tao", "nhà tao", "nha tao"):
        return ""
    return s


def _detect_ip_location() -> tuple[str, float, float]:
    try:
        data = _http_get_json("http://ip-api.com/json/?fields=status,city,regionName,country,lat,lon", timeout=6)
        if isinstance(data, dict) and data.get("status") == "success":
            name = data.get("city") or data.get("regionName") or "TP. Hồ Chí Minh"
            return str(name), float(data["lat"]), float(data["lon"])
    except Exception:
        pass
    try:
        data = _http_get_json("https://ipinfo.io/json", timeout=6)
        if isinstance(data, dict) and data.get("loc"):
            lat_s, lon_s = str(data["loc"]).split(",")
            return str(data.get("city") or "TP. Hồ Chí Minh"), float(lat_s), float(lon_s)
    except Exception:
        pass
    return "TP. Hồ Chí Minh", 10.8231, 106.6297


def get_live_weather(query: str = "") -> str:
    city = _extract_city(query)
    loc_name, lat, lon = None, None, None

    # 1. Nếu người dùng có nêu tên thành phố/tỉnh -> Geocode bằng Open-Meteo
    if city:
        try:
            q_enc = urllib.parse.quote(city)
            geo = _http_get_json(f"https://geocoding-api.open-meteo.com/v1/search?name={q_enc}&count=1&language=vi&format=json", timeout=8)
            if isinstance(geo, dict) and geo.get("results"):
                r0 = geo["results"][0]
                loc_name = r0.get("name") or city
                if r0.get("country"):
                    loc_name = f"{loc_name}, {r0['country']}"
                lat, lon = float(r0["latitude"]), float(r0["longitude"])
        except Exception:
            pass

    # 2. Nếu không nêu tên tỉnh/TP -> tự lấy vị trí hiện tại theo IP
    if lat is None or lon is None:
        loc_name, lat, lon = _detect_ip_location()

    # 3. Lấy dữ liệu thời tiết live từ Open-Meteo (không cần API key, siêu nhanh & ổn định)
    try:
        url = (
            f"https://api.open-meteo.com/v1/forecast?latitude={lat:.4f}&longitude={lon:.4f}"
            "&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m"
            "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max"
            "&timezone=auto&forecast_days=2"
        )
        w = _http_get_json(url, timeout=10)
        if isinstance(w, dict) and "current" in w:
            cur = w["current"]
            daily = w.get("daily", {})
            code = int(cur.get("weather_code", 0))
            desc = WMO_VI.get(code, f"Trạng thái mây/mưa (mã {code})")
            temp = cur.get("temperature_2m")
            feel = cur.get("apparent_temperature")
            hum = cur.get("relative_humidity_2m")
            wind = cur.get("wind_speed_10m")
            rain_now = cur.get("precipitation", 0)

            tmin = daily.get("temperature_2m_min", [None])[0]
            tmax = daily.get("temperature_2m_max", [None])[0]
            rain_prob = daily.get("precipitation_probability_max", [None])[0]

            lines = [
                f"Thời tiết hiện tại ở {loc_name}:",
                f"- Trời: {desc}",
                f"- Nhiệt độ: {temp}°C (cảm giác như {feel}°C)",
                f"- Độ ẩm: {hum}% | Gió: {wind} km/h | Lượng mưa hiện tại: {rain_now} mm",
            ]
            if tmin is not None and tmax is not None:
                rp_s = f" | Khả năng mưa hôm nay: {rain_prob}%" if rain_prob is not None else ""
                lines.append(f"- Trong ngày hôm nay: thấp nhất {tmin}°C, cao nhất {tmax}°C{rp_s}")
            if len(daily.get("temperature_2m_max", [])) >= 2:
                d2_code = int(daily.get("weather_code", [0, 0])[1])
                d2_desc = WMO_VI.get(d2_code, "Có mây")
                d2_min = daily["temperature_2m_min"][1]
                d2_max = daily["temperature_2m_max"][1]
                d2_rp = daily.get("precipitation_probability_max", [0, 0])[1]
                lines.append(f"- Dự báo ngày mai: {d2_desc}, {d2_min}°C đến {d2_max}°C, khả năng mưa {d2_rp}%")
            return "\n".join(lines)
    except Exception:
        pass

    # 4. Dự phòng wttr.in nếu Open-Meteo trục trặc
    try:
        q_wttr = urllib.parse.quote(city or loc_name or "Ho Chi Minh")
        data = _http_get_json(f"https://wttr.in/{q_wttr}?format=j1", timeout=10)
        if isinstance(data, dict) and data.get("current_condition"):
            c0 = data["current_condition"][0]
            desc = (c0.get("weatherDesc") or [{}])[0].get("value", "")
            return (
                f"Thời tiết hiện tại ở {city or loc_name}: {desc}, "
                f"nhiệt độ {c0.get('temp_C')}°C (cảm giác {c0.get('FeelsLikeC')}°C), "
                f"độ ẩm {c0.get('humidity')}%, gió {c0.get('windspeedKmph')} km/h."
            )
    except Exception:
        pass

    return "Không kết nối được máy chủ thời tiết (Open-Meteo & wttr.in đều timeout, kiểm tra lại kết nối mạng máy tính)."


def _search_ddgs(query: str, max_results: int = 5) -> list[str]:
    for mod_name in ("ddgs", "duckduckgo_search"):
        try:
            mod = __import__(mod_name, fromlist=["DDGS"])
            DDGS = getattr(mod, "DDGS")
            with DDGS() as ddgs:
                items = list(ddgs.text(query, region="vn-vi", max_results=max_results))
            out = []
            for it in items:
                title = str(it.get("title", "")).strip()
                body = str(it.get("body") or it.get("snippet") or "").strip()
                if title or body:
                    out.append(f"• {title}: {body}")
            if out:
                return out
        except Exception:
            continue
    return []


def _search_ddg_lite(query: str, max_results: int = 5) -> list[str]:
    try:
        data = urllib.parse.urlencode({"q": query, "kl": "vn-vi"}).encode("utf-8")
        req = urllib.request.Request(
            "https://lite.duckduckgo.com/lite/",
            data=data,
            headers={"User-Agent": UA, "Content-Type": "application/x-www-form-urlencoded"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=10) as r:
            page = r.read().decode("utf-8", errors="replace")
        titles = re.findall(r'class=["\']result-link["\'][^>]*>(.*?)</a>', page, flags=re.S | re.I)
        snips = re.findall(r'class=["\']result-snippet["\'][^>]*>(.*?)</td>', page, flags=re.S | re.I)
        out = []
        for idx, t in enumerate(titles[:max_results]):
            t_clean = html.unescape(re.sub(r"<[^>]+>", "", t)).strip()
            s_clean = html.unescape(re.sub(r"<[^>]+>", "", snips[idx])).strip() if idx < len(snips) else ""
            if t_clean:
                out.append(f"• {t_clean}: {s_clean}")
        return out
    except Exception:
        return []


def _search_bing_rss(query: str, max_results: int = 5) -> list[str]:
    try:
        q_enc = urllib.parse.quote(query)
        url = f"https://www.bing.com/search?q={q_enc}&format=rss&setlang=vi"
        req = urllib.request.Request(url, headers={"User-Agent": UA})
        with urllib.request.urlopen(req, timeout=10) as r:
            xml_raw = r.read()
        root = ET.fromstring(xml_raw)
        out = []
        for item in root.findall(".//item")[:max_results]:
            title = (item.findtext("title") or "").strip()
            desc = (item.findtext("description") or "").strip()
            if title:
                out.append(f"• {title}: {desc}")
        return out
    except Exception:
        return []


def _search_wikipedia_vi(query: str, max_results: int = 3) -> list[str]:
    try:
        q_enc = urllib.parse.quote(query)
        url = f"https://vi.wikipedia.org/w/api.php?action=query&list=search&srsearch={q_enc}&utf8=&format=json&srlimit={max_results}"
        data = _http_get_json(url, timeout=8)
        items = (data or {}).get("query", {}).get("search", [])
        out = []
        for it in items:
            title = str(it.get("title", "")).strip()
            snip = html.unescape(re.sub(r"<[^>]+>", "", str(it.get("snippet", "")))).strip()
            if title:
                out.append(f"• [Wikipedia] {title}: {snip}")
        return out
    except Exception:
        return []


def robust_web_search(query: str, max_results: int = 5) -> str:
    q = (query or "").strip()
    if not q:
        return "Vui lòng cung cấp từ khóa cần tìm kiếm."

    # Ưu tiên tuyệt đối: hỏi thời tiết -> lấy thẳng từ Open-Meteo/wttr.in
    if is_weather_query(q):
        return get_live_weather(q)

    for fn in (_search_ddgs, _search_bing_rss, _search_ddg_lite, _search_wikipedia_vi):
        res = fn(q, max_results)
        if res:
            return f"Kết quả tìm kiếm cho '{q}':\n" + "\n".join(res)

    return f"Không tìm thấy kết quả trực tuyến nào cho '{q}' (các nguồn tìm kiếm tạm thời không phản hồi)."

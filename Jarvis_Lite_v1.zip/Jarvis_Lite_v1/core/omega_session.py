﻿import json
import os
import threading
import time
from typing import Any, Dict, List

from core.semantic_memory import get_semantic_memory

SESSION_PATH = os.path.join("memory", "omega_session.json")
EXTRA_MEMORY_SOURCES = (
    os.path.join("memory", "brain_vault.json"),
    os.path.join("memory", "skills.json"),
)


class OmegaSessionBus:
    """
    Sợi dây hội thoại duy nhất dùng chung cho HUD (Trợ Lý), Nóc Nóc (Live Talk), Telegram & Stark Deck.
    Lưu bền vững ra memory/omega_session.json nên tiến trình khác nhau (vd Telegram Bot & HUD) vẫn thấy nhau tức thì.
    """

    def __init__(self, max_turns: int = 40):
        self._lock = threading.Lock()
        self.max_turns = max_turns
        self._synced_extra = False
        os.makedirs("memory", exist_ok=True)
        self._sync_extra_memories_once()

    def _sync_extra_memories_once(self) -> None:
        if self._synced_extra:
            return
        self._synced_extra = True
        sm = get_semantic_memory()
        flag_file = os.path.join("memory", ".omega_mem_synced_v1")
        if os.path.exists(flag_file):
            return
        try:
            for src in EXTRA_MEMORY_SOURCES:
                if not os.path.exists(src):
                    continue
                raw = json.load(open(src, "r", encoding="utf-8-sig"))
                if isinstance(raw, dict):
                    for k, v in raw.items():
                        if isinstance(v, list):
                            for it in v[-40:]:
                                txt = (it.get("content") or it.get("lesson") or it.get("goal") or str(it)) if isinstance(it, dict) else str(it)
                                if txt and len(txt.strip()) >= 5:
                                    sm.upsert_fact(txt.strip()[:350], category=str(k), importance=0.72)
                        elif isinstance(v, str) and len(v.strip()) >= 5:
                            sm.upsert_fact(f"{k}: {v.strip()[:300]}", category="vault", importance=0.75)
                elif isinstance(raw, list):
                    for it in raw[-40:]:
                        if isinstance(it, dict) and it.get("goal") and it.get("lesson"):
                            sm.record_playbook(str(it["goal"]), ["visual_gui_agent"], str(it["lesson"]))
                        elif isinstance(it, str) and len(it.strip()) >= 5:
                            sm.upsert_fact(it.strip()[:300], category="skill", importance=0.7)
            with open(flag_file, "w", encoding="utf-8") as f:
                f.write(str(int(time.time())))
        except Exception:
            pass

    def _read_file(self) -> List[Dict[str, Any]]:
        if not os.path.exists(SESSION_PATH):
            return []
        try:
            data = json.load(open(SESSION_PATH, "r", encoding="utf-8-sig"))
            return data if isinstance(data, list) else []
        except Exception:
            return []

    def _write_file(self, turns: List[Dict[str, Any]]) -> None:
        tmp = f"{SESSION_PATH}.{os.getpid()}.tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(turns[-self.max_turns :], f, ensure_ascii=False, indent=2)
        os.replace(tmp, SESSION_PATH)

    def append_turn(self, source: str, user_text: str, assistant_text: str, meta: Dict[str, Any] | None = None) -> None:
        now_s = time.strftime("%H:%M %d/%m")
        with self._lock:
            turns = self._read_file()
            turns.append({
                "ts": time.time(),
                "time_str": now_s,
                "source": source,
                "user": (user_text or "").strip(),
                "assistant": (assistant_text or "").strip(),
                "meta": meta or {},
            })
            self._write_file(turns)

    def get_llm_messages(self, limit: int = 10) -> List[Dict[str, str]]:
        with self._lock:
            turns = self._read_file()[-limit:]
        msgs: List[Dict[str, str]] = []
        for t in turns:
            src = t.get("source", "hud")
            u = t.get("user", "")
            a = t.get("assistant", "")
            if u:
                msgs.append({"role": "user", "content": f"[{src} | {t.get('time_str','')}] {u}"})
            if a:
                msgs.append({"role": "assistant", "content": a})
        return msgs

    def get_recent_turns(self, limit: int = 10) -> List[Dict[str, Any]]:
        with self._lock:
            return self._read_file()[-limit:]

    def clear(self) -> None:
        with self._lock:
            self._write_file([])


_SESSION_BUS = OmegaSessionBus()


def get_session_bus() -> OmegaSessionBus:
    return _SESSION_BUS

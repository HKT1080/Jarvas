import datetime
import json
import os
import re
import threading
import time
import uuid
import winsound
import requests

REMINDERS_PATH = os.path.join("memory", "reminders.json")

_NUM_WORDS = {
    "một": 1, "mot": 1, "hai": 2, "ba": 3, "bốn": 4, "bon": 4, "tư": 4,
    "năm": 5, "nam": 5, "sáu": 6, "sau": 6, "bảy": 7, "bay": 7, "tám": 8, "tam": 8,
    "chín": 9, "chin": 9, "mười": 10, "muoi": 10, "mười lăm": 15, "hai mươi": 20, "ba mươi": 30,
}

REMINDER_TRIGGERS = (
    "nhắc tao", "nhắc mình", "nhắc anh", "nhắc tôi", "báo tao", "hẹn giờ",
    "đặt báo thức", "đặt lịch nhắc", "nhắc việc", "nhắc giùm", "nhắc giúp",
)


def _send_tg_reminder(text: str) -> None:
    try:
        from core.secret_dpapi import load_telegram_decrypted
        token, chat_id = load_telegram_decrypted()
        if token and chat_id:
            requests.post(
                f"https://api.telegram.org/bot{token}/sendMessage",
                json={"chat_id": chat_id, "text": "⏰ NHẮC VIỆC TỪ JARVIS:\n" + str(text)},
                timeout=10,
            )
    except Exception:
        pass



def _clean_task(raw: str) -> str:
    s = re.sub(
        r"(?i)^(hãy|giúp|giùm|nhớ|nhắc tao|nhắc mình|nhắc tôi|nhắc anh|báo tao|hẹn giờ|đặt lịch nhắc|đặt báo thức|nhắc|báo|rằng|là|đi|nha|nhé)\s+",
        "",
        (raw or "").strip(" ,.:;-!?"),
    )
    s = re.sub(r"(?i)^(tao|mình|tôi|anh|giùm|giúp|là)\s+", "", s).strip(" ,.:;-!?")
    return s if len(s) >= 2 else "Có việc cần làm mày vừa dặn"


def parse_vietnamese_reminder(text: str, now: datetime.datetime | None = None) -> dict | None:
    """
    Bắt tự nhiên câu nhắc việc tiếng Việt:
      - '30 giây nữa nhắc tao tắt bếp'
      - '15 phút nữa nhắc tao uống nước'
      - 'nửa tiếng nữa nhắc tao họp'
      - '8 giờ tối nay nhắc tao nộp bài' / '20h30 nhắc tao...' / '7h sáng mai nhắc...'
    """
    s = (text or "").strip()
    low = s.lower()
    if not any(k in low for k in REMINDER_TRIGGERS):
        return None

    now = now or datetime.datetime.now()

    # 1. Dạng tương đối: "nửa tiếng nữa"
    m_half = re.search(r"(?i)(nửa tiếng|nua tieng|nửa giờ|nua gio)\s*(nữa|nua)?", s)
    if m_half:
        due = now + datetime.timedelta(minutes=30)
        rest = (s[: m_half.start()] + " " + s[m_half.end() :]).strip()
        return {"due_ts": due.timestamp(), "due_str": due.strftime("%H:%M:%S %d/%m/%Y"), "task": _clean_task(rest)}

    # 2. Dạng tương đối: "X giây / phút / tiếng / giờ nữa" hoặc "sau X phút"
    m_rel = re.search(
        r"(?i)(?:sau\s+)?(\d+(?:[.,]\d+)?)\s*(giây|giay|s|phút|phut|p|tiếng|tieng|giờ|gio|h)\s*(rưỡi|ruoi)?\s*(nữa|nua)?",
        s,
    )
    if m_rel and (m_rel.group(4) or "sau " in low[: m_rel.start() + 5] or m_rel.group(2).lower() in ("giây", "giay", "phút", "phut", "tiếng", "tieng")):
        val = float(m_rel.group(1).replace(",", "."))
        unit = m_rel.group(2).lower()
        half_extra = 0.5 if m_rel.group(3) else 0.0
        if unit in ("giây", "giay", "s"):
            delta = datetime.timedelta(seconds=val)
        elif unit in ("phút", "phut", "p"):
            delta = datetime.timedelta(minutes=val + half_extra)
        else:
            delta = datetime.timedelta(hours=val + half_extra)
        due = now + delta
        rest = (s[: m_rel.start()] + " " + s[m_rel.end() :]).strip()
        return {"due_ts": due.timestamp(), "due_str": due.strftime("%H:%M:%S %d/%m/%Y"), "task": _clean_task(rest)}

    # 3. Dạng giờ cụ thể: "8h30 tối nay", "20:15", "7 giờ sáng mai", "lúc 9 giờ"
    m_abs = re.search(
        r"(?i)(?:lúc\s+|vào\s+)?(\d{1,2})\s*(?:giờ|gio|h|:)\s*(\d{1,2})?\s*(phút|phut)?\s*(sáng|sang|trưa|trua|chiều|chieu|tối|toi|đêm|dem)?\s*(hôm nay|hom nay|tối nay|toi nay|ngày mai|ngay mai|mai)?",
        s,
    )
    if m_abs:
        hr = int(m_abs.group(1))
        mn = int(m_abs.group(2) or 0)
        period = (m_abs.group(4) or "").lower()
        day_kw = (m_abs.group(5) or "").lower()

        if period in ("chiều", "chieu", "tối", "toi", "đêm", "dem") and 1 <= hr <= 11:
            hr += 12
        elif period in ("trưa", "trua") and 1 <= hr <= 3:
            hr += 12
        if "tối" in day_kw or "toi" in day_kw:
            if 1 <= hr <= 11:
                hr += 12

        if 0 <= hr <= 23 and 0 <= mn <= 59:
            due = now.replace(hour=hr, minute=mn, second=0, microsecond=0)
            if "mai" in day_kw:
                if due.date() == now.date():
                    due += datetime.timedelta(days=1)
            elif due <= now:
                due += datetime.timedelta(days=1)
            rest = (s[: m_abs.start()] + " " + s[m_abs.end() :]).strip()
            return {"due_ts": due.timestamp(), "due_str": due.strftime("%H:%M %d/%m/%Y"), "task": _clean_task(rest)}

    return None


class ProactiveScheduler:
    """Lịch nhắc việc chủ động chạy ngầm: lưu bền vững JSON -> tới giờ tự gọi loa + popup + Telegram."""

    def __init__(self):
        self._lock = threading.Lock()
        self._running = False
        self._hud = None
        self.reminders: list[dict] = []
        self._load()

    def _load(self):
        os.makedirs("memory", exist_ok=True)
        if os.path.exists(REMINDERS_PATH):
            try:
                data = json.load(open(REMINDERS_PATH, "r", encoding="utf-8-sig"))
                if isinstance(data, list):
                    self.reminders = data
            except Exception:
                self.reminders = []

    def _save(self):
        os.makedirs("memory", exist_ok=True)
        tmp = REMINDERS_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.reminders, f, ensure_ascii=False, indent=2)
        os.replace(tmp, REMINDERS_PATH)

    def start(self, hud=None):
        if hud is not None:
            self._hud = hud
        if self._running:
            return
        self._running = True
        threading.Thread(target=self._loop, daemon=True).start()

    def add(self, task: str, due_ts: float) -> dict:
        due_dt = datetime.datetime.fromtimestamp(due_ts)
        item = {
            "id": uuid.uuid4().hex[:8],
            "task": (task or "Việc cần làm").strip(),
            "due_ts": float(due_ts),
            "due_str": due_dt.strftime("%H:%M:%S %d/%m/%Y"),
            "done": False,
            "created_at": time.strftime("%H:%M %d/%m/%Y"),
        }
        with self._lock:
            self._load()
            self.reminders.append(item)
            self._save()
        return item

    def add_from_text(self, text: str) -> dict | None:
        parsed = parse_vietnamese_reminder(text)
        if not parsed:
            return None
        return self.add(parsed["task"], parsed["due_ts"])

    def list_pending(self) -> list[dict]:
        with self._lock:
            self._load()
            items = [r for r in self.reminders if not r.get("done")]
        items.sort(key=lambda x: x.get("due_ts", 0))
        return items

    def delete(self, key: str) -> int:
        k = (key or "").strip().lower()
        with self._lock:
            self._load()
            before = len(self.reminders)
            if k in ("all", "tất cả", "het", "hết"):
                self.reminders = []
            else:
                self.reminders = [
                    r for r in self.reminders
                    if r.get("id", "").lower() != k and k not in r.get("task", "").lower()
                ]
            removed = before - len(self.reminders)
            if removed:
                self._save()
        return removed

    def _fire_reminder(self, item: dict):
        task = item.get("task", "việc mày vừa dặn")
        spoken = f"Ê mày ơi, tới giờ rồi! Tao nhắc mày: {task} nha!"

        try:
            for freq in (980, 1240, 1480):
                winsound.Beep(freq, 110)
        except Exception:
            pass

        # 1. Bắn tin nhắn nhắc qua Telegram
        threading.Thread(target=_send_tg_reminder, args=(f"Tới giờ rồi mày ơi: {task}",), daemon=True).start()

        # 2. Cất tiếng nhắc thẳng ra loa qua Fast TTS
        try:
            from core.fast_tts import get_speaker
            get_speaker().speak_async(spoken, rate="+12%")
        except Exception:
            pass

        # 3. Hiện banner nhắc nổi Cyberpunk nếu HUD đang chạy
        if self._hud is not None and getattr(self._hud, "root", None) is not None:
            def _popup():
                try:
                    import tkinter as tk
                    top = tk.Toplevel(self._hud.root)
                    top.overrideredirect(True)
                    top.attributes("-topmost", True)
                    top.configure(bg="#fbbf24")
                    sw = top.winfo_screenwidth()
                    w, h = 420, 108
                    top.geometry(f"{w}x{h}+{sw - w - 24}+64")
                    inner = tk.Frame(top, bg="#0b1322", padx=14, pady=10)
                    inner.pack(fill="both", expand=True, padx=2, pady=2)
                    tk.Label(inner, text="⏰ NHẮC VIỆC CHỦ ĐỘNG TỪ JARVIS", font=("Segoe UI", 10, "bold"), bg="#0b1322", fg="#fbbf24").pack(anchor="w")
                    tk.Label(inner, text=task, font=("Segoe UI", 10), bg="#0b1322", fg="#f8fafc", wraplength=385, justify="left").pack(anchor="w", pady=(4, 0))
                    tk.Button(inner, text="✖", bg="#ef4444", fg="#fff", relief="flat", font=("Segoe UI", 8, "bold"), command=top.destroy).place(x=370, y=0)
                    top.after(14000, lambda: top.destroy() if top.winfo_exists() else None)
                except Exception:
                    pass
            try:
                self._hud.root.after(0, _popup)
            except Exception:
                pass

    def _loop(self):
        while self._running:
            try:
                now_ts = time.time()
                due_list = []
                with self._lock:
                    self._load()
                    changed = False
                    for r in self.reminders:
                        if not r.get("done") and float(r.get("due_ts", 0)) <= now_ts:
                            r["done"] = True
                            r["fired_at"] = time.strftime("%H:%M:%S %d/%m/%Y")
                            due_list.append(dict(r))
                            changed = True
                    if changed:
                        # Giữ lại tối đa 30 lịch đã xong gần nhất
                        pending = [r for r in self.reminders if not r.get("done")]
                        done = [r for r in self.reminders if r.get("done")][-30:]
                        self.reminders = pending + done
                        self._save()
                for item in due_list:
                    self._fire_reminder(item)
            except Exception:
                pass
            time.sleep(2.0)


_SCHEDULER = ProactiveScheduler()


def get_scheduler() -> ProactiveScheduler:
    return _SCHEDULER

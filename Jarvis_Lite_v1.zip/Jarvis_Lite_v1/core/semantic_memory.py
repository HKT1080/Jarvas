﻿import hashlib
import json
import math
import os
import re
import threading
import time
import unicodedata

STORE_PATH = os.path.join("memory", "semantic_store.json")
LEGACY_UNIFIED = os.path.join("memory", "unified_memory.json")
LEGACY_FLAT = "jarvis_memory.json"

_VI_STOPWORDS = {
    "và", "là", "của", "cho", "với", "có", "không", "được", "trong", "này", "kia",
    "một", "những", "các", "thì", "mà", "để", "tôi", "tao", "mày", "bạn", "nha",
    "nhé", "ơi", "à", "ừ", "đi", "đã", "đang", "sẽ", "làm", "gì", "sao", "nhớ",
    "va", "la", "cua", "voi", "khong", "duoc", "nay", "mot", "nhung", "cac", "thi", "de",
}


def _fold_vi(text: str) -> str:
    s = (text or "").lower().replace("đ", "d")
    s = unicodedata.normalize("NFKD", s)
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    return re.sub(r"\s+", " ", s).strip()


def _tokenize(text: str) -> list[str]:
    raw_toks = re.findall(r"[a-zA-ZÀ-ỹ0-9_]+", (text or "").lower())
    folded_toks = re.findall(r"[a-z0-9_]+", _fold_vi(text))
    out = [t for t in raw_toks if len(t) >= 2 and t not in _VI_STOPWORDS]
    out.extend(t for t in folded_toks if len(t) >= 2 and t not in _VI_STOPWORDS and t not in out)
    return out


def _char_ngrams(text: str, n: int = 3) -> set[str]:
    f = re.sub(r"[^a-z0-9 ]", "", _fold_vi(text))
    if len(f) < n:
        return {f} if f else set()
    return {f[i : i + n] for i in range(len(f) - n + 1)}


def _pair_similarity(a: str, b: str) -> float:
    ta, tb = set(_tokenize(a)), set(_tokenize(b))
    ga, gb = _char_ngrams(a), _char_ngrams(b)
    j_tok = (len(ta & tb) / max(1, len(ta | tb))) if (ta or tb) else 0.0
    j_ng = (len(ga & gb) / max(1, len(ga | gb))) if (ga or gb) else 0.0
    return 0.55 * j_tok + 0.45 * j_ng


class SemanticMemory:
    """
    Trí Nhớ Ngữ Nghĩa Dài Hạn + Tự Hợp Nhất Chống Mâu Thuẫn + Sổ Tay Kinh Nghiệm (Playbooks).
    Tìm kiếm lai BM25 + Character N-gram Tiếng Việt + Suy giảm thời gian (<5ms, 0 MB tải model).
    """

    def __init__(self):
        self._lock = threading.Lock()
        self.data = {"facts": [], "playbooks": [], "migrated": False}
        self._load()
        self._sync_legacy_once()

    def _load(self):
        os.makedirs("memory", exist_ok=True)
        if os.path.exists(STORE_PATH):
            try:
                d = json.load(open(STORE_PATH, "r", encoding="utf-8-sig"))
                if isinstance(d, dict):
                    self.data["facts"] = d.get("facts", [])
                    self.data["playbooks"] = d.get("playbooks", [])
                    self.data["migrated"] = bool(d.get("migrated", False))
            except Exception:
                pass

    def _save(self):
        os.makedirs("memory", exist_ok=True)
        tmp = STORE_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.data, f, ensure_ascii=False, indent=2)
        os.replace(tmp, STORE_PATH)

    def _sync_legacy_once(self):
        if self.data.get("migrated"):
            return
        imported = []
        for path in (LEGACY_UNIFIED, LEGACY_FLAT):
            if not os.path.exists(path):
                continue
            try:
                raw = json.load(open(path, "r", encoding="utf-8-sig"))
                if isinstance(raw, dict):
                    for cat, val in raw.items():
                        if isinstance(val, list):
                            for item in val:
                                txt = (item.get("content") or item.get("text") or str(item)) if isinstance(item, dict) else str(item)
                                if txt and len(txt.strip()) >= 4:
                                    imported.append((str(cat), txt.strip()))
                        elif isinstance(val, dict):
                            for k2, v2 in val.items():
                                imported.append((str(cat), f"{k2}: {v2}"))
                        elif isinstance(val, str) and len(val.strip()) >= 4:
                            imported.append((str(cat), val.strip()))
                elif isinstance(raw, list):
                    for item in raw:
                        txt = str(item).strip()
                        if len(txt) >= 4:
                            imported.append(("general", txt))
            except Exception:
                continue

        with self._lock:
            for cat, txt in imported[-180:]:
                self._upsert_unlocked(txt, category=cat, importance=0.65)
            self.data["migrated"] = True
            self._save()

    def _upsert_unlocked(self, content: str, category: str = "general", topic: str = "", importance: float = 0.8) -> tuple[str, str]:
        content = re.sub(r"\s+", " ", (content or "")).strip()
        if len(content) < 3:
            return "SKIP", ""

        now_ts = time.time()
        now_str = time.strftime("%Y-%m-%d %H:%M")
        topic_clean = _fold_vi(topic)

        # Kiểm tra trùng lặp hoặc mâu thuẫn để CẬP NHẬT đè lên thông tin cũ
        best_idx, best_sim = -1, 0.0
        for idx, item in enumerate(self.data["facts"]):
            if topic_clean and _fold_vi(item.get("topic", "")) == topic_clean:
                best_idx, best_sim = idx, 1.0
                break
            sim = _pair_similarity(content, item.get("content", ""))
            if sim > best_sim:
                best_idx, best_sim = idx, sim

        if best_idx != -1 and best_sim >= 0.56:
            old = self.data["facts"][best_idx]
            old_txt = old.get("content", "")
            if _fold_vi(old_txt) == _fold_vi(content):
                old["updated_ts"] = now_ts
                old["updated_at"] = now_str
                old["hits"] = int(old.get("hits", 1)) + 1
                return "REFRESHED", old["id"]
            # Ghi đè mâu thuẫn / cập nhật thông tin mới hơn
            old["prev_content"] = old_txt
            old["content"] = content
            old["category"] = category or old.get("category", "general")
            if topic:
                old["topic"] = topic
            old["updated_ts"] = now_ts
            old["updated_at"] = now_str
            old["importance"] = max(float(old.get("importance", 0.7)), importance)
            return "UPDATED", old["id"]

        fid = hashlib.md5(f"{content}_{now_ts}".encode("utf-8")).hexdigest()[:10]
        self.data["facts"].append({
            "id": fid,
            "category": category or "general",
            "topic": topic,
            "content": content,
            "importance": float(importance),
            "created_at": now_str,
            "updated_at": now_str,
            "updated_ts": now_ts,
            "hits": 1,
        })
        # Giữ tối đa 500 ký ức giá trị nhất
        if len(self.data["facts"]) > 500:
            self.data["facts"].sort(key=lambda x: (x.get("importance", 0.5), x.get("updated_ts", 0)), reverse=True)
            self.data["facts"] = self.data["facts"][:500]
        return "ADDED", fid

    def upsert_fact(self, content: str, category: str = "general", topic: str = "", importance: float = 0.8) -> tuple[str, str]:
        with self._lock:
            status, fid = self._upsert_unlocked(content, category=category, topic=topic, importance=importance)
            self._save()
        # Đồng bộ nhẹ sang unified_memory.json để tương thích ngược bản cũ
        try:
            u = json.load(open(LEGACY_UNIFIED, "r", encoding="utf-8-sig")) if os.path.exists(LEGACY_UNIFIED) else {}
            if isinstance(u, dict):
                arr = u.setdefault("facts", [])
                if isinstance(arr, list):
                    arr.append({"content": content, "ts": time.strftime("%Y-%m-%d %H:%M")})
                    u["facts"] = arr[-100:]
                    with open(LEGACY_UNIFIED, "w", encoding="utf-8") as f:
                        json.dump(u, f, ensure_ascii=False, indent=2)
        except Exception:
            pass
        return status, fid

    def delete_fact(self, fid: str) -> bool:
        with self._lock:
            before = len(self.data["facts"])
            self.data["facts"] = [x for x in self.data["facts"] if x.get("id") != fid]
            if len(self.data["facts"]) != before:
                self._save()
                return True
        return False

    def record_playbook(self, trigger: str, tools_used: list[str], lesson: str) -> str:
        """Lưu Sổ Tay Kinh Nghiệm (Procedural Playbook) sau khi giải quyết thành công hoặc tự sửa lỗi."""
        trigger = (trigger or "").strip()[:180]
        lesson = (lesson or "").strip()[:320]
        if not trigger or not lesson:
            return ""
        with self._lock:
            now_str = time.strftime("%Y-%m-%d %H:%M")
            for pb in self.data["playbooks"]:
                if _pair_similarity(trigger, pb.get("trigger", "")) >= 0.62:
                    pb["tools"] = tools_used
                    pb["lesson"] = lesson
                    pb["updated_at"] = now_str
                    pb["uses"] = int(pb.get("uses", 1)) + 1
                    self._save()
                    return pb["id"]
            pid = "pb_" + hashlib.md5(f"{trigger}_{time.time()}".encode("utf-8")).hexdigest()[:8]
            self.data["playbooks"].append({
                "id": pid,
                "trigger": trigger,
                "tools": tools_used,
                "lesson": lesson,
                "updated_at": now_str,
                "uses": 1,
            })
            self.data["playbooks"] = self.data["playbooks"][-120:]
            self._save()
            return pid

    def recall(self, query: str, top_k: int = 5) -> list[dict]:
        """Truy xuất Top-K ký ức ngữ nghĩa liên quan nhất bằng BM25 + N-gram + Recency."""
        with self._lock:
            docs = list(self.data["facts"])
        if not docs:
            return []

        q_toks = _tokenize(query)
        q_ng = _char_ngrams(query)
        N = len(docs)
        doc_toks = [_tokenize(f"{d.get('topic','')} {d.get('category','')} {d.get('content','')}") for d in docs]
        avgdl = sum(len(t) for t in doc_toks) / max(1, N)

        # Tính IDF cho từng token trong câu hỏi
        df = {}
        for qt in set(q_toks):
            df[qt] = sum(1 for dt in doc_toks if qt in dt)

        now_ts = time.time()
        scored = []
        for idx, d in enumerate(docs):
            dt = doc_toks[idx]
            dl = len(dt)
            bm25 = 0.0
            for qt in q_toks:
                tf = dt.count(qt)
                if tf > 0:
                    idf = math.log((N - df.get(qt, 0) + 0.5) / (df.get(qt, 0) + 0.5) + 1.0)
                    bm25 += idf * (tf * 2.2) / (tf + 1.2 * (1.0 - 0.75 + 0.75 * dl / max(1.0, avgdl)))

            d_ng = _char_ngrams(d.get("content", ""))
            ng_sim = (len(q_ng & d_ng) / max(1, len(q_ng | d_ng))) if (q_ng and d_ng) else 0.0
            age_days = max(0.0, (now_ts - float(d.get("updated_ts", now_ts))) / 86400.0)
            recency_boost = 1.0 / (1.0 + age_days / 45.0)
            imp = float(d.get("importance", 0.7))

            score = bm25 * 0.65 + ng_sim * 4.5 + recency_boost * 0.35 + imp * 0.25
            if bm25 > 0.05 or ng_sim >= 0.14:
                scored.append((score, d))

        scored.sort(key=lambda x: x[0], reverse=True)
        picked = [d for _, d in scored[:top_k]]
        # Bổ sung 2 ký ức mới nhất nếu chưa đủ ngữ cảnh chung
        if len(picked) < min(3, len(docs)):
            recent = sorted(docs, key=lambda x: x.get("updated_ts", 0), reverse=True)
            seen = {p["id"] for p in picked}
            for r in recent:
                if r["id"] not in seen:
                    picked.append(r)
                    seen.add(r["id"])
                if len(picked) >= min(top_k, len(docs)):
                    break
        return picked

    def recall_playbooks(self, query: str, top_k: int = 2) -> list[dict]:
        with self._lock:
            pbs = list(self.data["playbooks"])
        if not pbs:
            return []
        scored = []
        for pb in pbs:
            sim = _pair_similarity(query, f"{pb.get('trigger','')} {pb.get('lesson','')}")
            if sim >= 0.16:
                scored.append((sim, pb))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [pb for _, pb in scored[:top_k]]

    def format_context(self, query: str, top_k: int = 5) -> str:
        facts = self.recall(query, top_k=top_k)
        pbs = self.recall_playbooks(query, top_k=2)
        lines = []
        if facts:
            lines.append("TRÍ NHỚ NGỮ NGHĨA LIÊN QUAN:")
            for f in facts:
                lines.append(f"- [{f.get('category','general')} | {f.get('updated_at','')}] {f.get('content','')}")
        if pbs:
            lines.append("SỔ TAY KINH NGHIỆM (PLAYBOOKS ĐÃ HỌC):")
            for pb in pbs:
                tools_s = ", ".join(pb.get("tools", []))
                lines.append(f"- Khi gặp '{pb.get('trigger','')}' -> dùng [{tools_s}]: {pb.get('lesson','')}")
        return "\n".join(lines)

    def get_all(self) -> dict:
        with self._lock:
            return {
                "facts": list(self.data["facts"]),
                "playbooks": list(self.data["playbooks"]),
            }


_SEM_MEM = SemanticMemory()


def get_semantic_memory() -> SemanticMemory:
    return _SEM_MEM

﻿import base64
import ctypes
from ctypes import wintypes
import io
import os
import re
import threading
import time
import psutil
from PIL import Image, ImageGrab

_user32 = ctypes.windll.user32
_kernel32 = ctypes.windll.kernel32
CF_UNICODETEXT = 13

_IGNORE_TITLES = (
    "jarvis", "stark", "nóc nóc", "iq center", "program manager",
    "windows input experience", "search", "task switching",
)

DEICTIC_PATTERNS = (
    r"\bcái này\b", r"\blỗi này\b", r"\bđoạn này\b", r"\btrang này\b", r"\bweb này\b",
    r"\bmàn hình này\b", r"\bchỗ này\b", r"\bđang mở\b", r"\bđang xem\b", r"\bđang hiện\b",
    r"\btrên màn hình\b", r"\bcode này\b", r"\bbài này\b", r"\bfile này\b", r"\bảnh này\b",
    r"\bđoạn trên\b", r"\bđoạn vừa copy\b", r"\bvừa copy\b", r"\bclipboard\b", r"\btrong này\b",
    r"\bnhìn màn hình\b", r"\bsoi màn hình\b", r"\bcái vừa rồi\b", r"\bnhư trên\b",
)


def is_deictic_query(text: str) -> bool:
    low = (text or "").lower()
    return any(re.search(pat, low) for pat in DEICTIC_PATTERNS)


def get_foreground_info() -> tuple[str, str]:
    """Trả về (process_name, window_title) của cửa sổ đang active."""
    try:
        hwnd = _user32.GetForegroundWindow()
        if not hwnd:
            return "", ""
        length = _user32.GetWindowTextLengthW(hwnd)
        title = ""
        if length > 0:
            buf = ctypes.create_unicode_buffer(length + 1)
            _user32.GetWindowTextW(hwnd, buf, length + 1)
            title = buf.value.strip()
        pid = wintypes.DWORD()
        _user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        proc_name = ""
        if pid.value:
            try:
                proc_name = psutil.Process(pid.value).name()
            except Exception:
                proc_name = ""
        return proc_name, title
    except Exception:
        return "", ""


def read_clipboard_text(max_chars: int = 1200) -> str:
    """Đọc nhanh văn bản trong Clipboard Windows (an toàn, không ghi đè)."""
    for _ in range(3):
        if _user32.OpenClipboard(None):
            try:
                if not _user32.IsClipboardFormatAvailable(CF_UNICODETEXT):
                    return ""
                hdata = _user32.GetClipboardData(CF_UNICODETEXT)
                if not hdata:
                    return ""
                ptr = _kernel32.GlobalLock(hdata)
                if not ptr:
                    return ""
                try:
                    raw = ctypes.wstring_at(ptr)
                    return re.sub(r"\r\n?", "\n", raw).strip()[:max_chars]
                finally:
                    _kernel32.GlobalUnlock(hdata)
            except Exception:
                return ""
            finally:
                _user32.CloseClipboard()
        time.sleep(0.03)
    return ""


def capture_screen_b64(max_width: int = 1280, quality: int = 70) -> str | None:
    """Chụp nhanh màn hình hiện tại nén JPEG base64 phục vụ hiểu ngữ cảnh tức thì."""
    try:
        img = ImageGrab.grab()
        if img.width > max_width:
            ratio = max_width / float(img.width)
            img = img.resize((max_width, int(img.height * ratio)), Image.LANCZOS)
        buf = io.BytesIO()
        img.convert("RGB").save(buf, format="JPEG", quality=quality, optimize=True)
        return base64.b64encode(buf.getvalue()).decode("utf-8")
    except Exception:
        return None


class AmbientMonitor:
    """Cảm biến chạy ngầm (0% CPU) ghi nhớ cửa sổ làm việc gần nhất và clipboard."""

    def __init__(self):
        self._lock = threading.Lock()
        self._running = False
        self.last_work_app = ""
        self.last_work_title = ""
        self.recent_windows: list[str] = []
        self.last_clipboard = ""
        self.last_update_ts = 0.0

    def start(self):
        if self._running:
            return
        self._running = True
        threading.Thread(target=self._loop, daemon=True).start()

    def _is_jarvis_window(self, proc: str, title: str) -> bool:
        t = (title or "").lower()
        p = (proc or "").lower()
        if not t:
            return True
        if any(ig in t for ig in _IGNORE_TITLES):
            return True
        if p in ("python.exe", "pythonw.exe") and ("jarvis" in t or "tk" == t):
            return True
        return False

    def _poll_once(self):
        proc, title = get_foreground_info()
        clip = read_clipboard_text(900)
        with self._lock:
            self.last_update_ts = time.time()
            if clip:
                self.last_clipboard = clip
            if title and not self._is_jarvis_window(proc, title):
                self.last_work_app = proc
                self.last_work_title = title
                label = f"{proc}: {title[:90]}" if proc else title[:90]
                if not self.recent_windows or self.recent_windows[-1] != label:
                    self.recent_windows.append(label)
                    self.recent_windows = self.recent_windows[-6:]

    def _loop(self):
        while self._running:
            try:
                self._poll_once()
            except Exception:
                pass
            time.sleep(1.2)

    def get_snapshot(self, refresh: bool = True) -> dict:
        if refresh:
            self._poll_once()
        with self._lock:
            return {
                "app": self.last_work_app or "Desktop",
                "title": self.last_work_title or "Màn hình chính Windows",
                "recent": list(self.recent_windows),
                "clipboard": self.last_clipboard,
            }

    def format_for_prompt(self, include_clipboard: bool = True) -> str:
        snap = self.get_snapshot(refresh=True)
        lines = [
            f"CỬA SỔ ĐANG LÀM VIỆC: [{snap['app']}] {snap['title']}",
        ]
        if len(snap["recent"]) > 1:
            lines.append("CỬA SỔ MỞ GẦN ĐÂY: " + " -> ".join(snap["recent"][-4:]))
        if include_clipboard and snap["clipboard"]:
            clip_preview = snap["clipboard"].replace("\n", " ")[:480]
            lines.append(f"CLIPBOARD (CHỮ VỪA COPY): \"{clip_preview}\"")
        return "\n".join(lines)


_MONITOR = AmbientMonitor()


def get_ambient_monitor() -> AmbientMonitor:
    return _MONITOR

﻿import json
import os
import sys
import requests

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from core.secret_dpapi import load_config_decrypted

_ORIG_POST = requests.post
_INSTALLED = False

HEAVY_TOOLS = {
    "auto_learner.py",
    "ai_council.py",
    "phoenix_healer.py",
    "deep_researcher.py",
    "dream_core.py",
    "omni_orchestrator.py",
    "screen_brain.py",
}


def load_vlm_cfg():
    cfg_path = os.path.join(_ROOT, "config.json")
    return load_config_decrypted(cfg_path).get("vlm", {})


class _CompatResponse:
    def __init__(self, text: str, status_code: int = 200):
        self._text = text
        self.status_code = status_code
        self.text = text

    def raise_for_status(self):
        if self.status_code >= 400:
            raise requests.HTTPError(f"HTTP {self.status_code}: {self._text[:250]}")

    def json(self):
        return {"candidates": [{"content": {"parts": [{"text": self._text}]}}]}


def _post_chat(endpoint, headers, model, content, max_tokens, temperature, timeout):
    payload = {
        "model": model,
        "temperature": temperature,
        "max_tokens": max_tokens,
        "messages": [{"role": "user", "content": content}],
    }
    resp = _ORIG_POST(endpoint, json=payload, headers=headers, timeout=timeout)
    resp.raise_for_status()
    body = resp.json()
    return body["choices"][0]["message"]["content"].strip()


def call_vlm(parts, max_tokens: int = 4096, temperature: float = 0.3, timeout: int = 60) -> str:
    vlm = load_vlm_cfg()
    endpoint = str(vlm.get("endpoint", "")).strip()
    base_model = str(vlm.get("fast_model") or vlm.get("model") or "gemini-3.5-flash-lite").strip()
    pro_model = str(vlm.get("pro_model") or base_model).strip()
    api_key = str(vlm.get("api_key", "")).strip()

    if not endpoint:
        raise RuntimeError("Thiếu vlm.endpoint trong config.json!")

    caller = os.path.basename(sys.argv[0]).lower() if sys.argv else ""
    primary_model = pro_model if (pro_model and caller in HEAVY_TOOLS) else base_model

    has_img = any("inline_data" in p for p in parts if isinstance(p, dict))
    if has_img:
        content = []
        for p in parts:
            if "text" in p:
                content.append({"type": "text", "text": p["text"]})
            elif "inline_data" in p:
                mime = p["inline_data"].get("mime_type", "image/jpeg")
                b64 = p["inline_data"].get("data", "")
                content.append({"type": "image_url", "image_url": {"url": f"data:{mime};base64,{b64}"}})
    else:
        content = "\n".join(p.get("text", "") for p in parts if isinstance(p, dict) and "text" in p)

    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    try:
        return _post_chat(endpoint, headers, primary_model, content, max_tokens, temperature, timeout)
    except Exception:
        if primary_model != base_model:
            return _post_chat(endpoint, headers, base_model, content, max_tokens, temperature, timeout)
        raise


def install_shim():
    global _INSTALLED
    if _INSTALLED:
        return
    _INSTALLED = True

    vlm = load_vlm_cfg()
    if vlm.get("api_key"):
        os.environ["GEMINI_API_KEY"] = str(vlm["api_key"]).strip()

    def _wrapped_post(url, *args, **kwargs):
        if ":generateContent" in str(url):
            body = kwargs.get("json") or {}
            contents = body.get("contents") or []
            parts = contents[0].get("parts", []) if contents else []
            timeout = max(int(kwargs.get("timeout", 45)), 60)
            txt = call_vlm(parts, max_tokens=4096, temperature=0.3, timeout=timeout)
            return _CompatResponse(txt, 200)
        return _ORIG_POST(url, *args, **kwargs)

    requests.post = _wrapped_post

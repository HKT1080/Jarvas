﻿import json
import os
import shutil
import socket
import subprocess
import threading
import time
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import psutil

from core.ambient_context import get_ambient_monitor
from core.fast_tts import get_speaker
from core.lite_kernel import get_lite_kernel
from core.omega_session import get_session_bus
from core.proactive_scheduler import get_scheduler
from core.semantic_memory import get_semantic_memory

_JOBS: dict[str, dict] = {}
_JOBS_LOCK = threading.Lock()
_SRV = {"port": None}

HTML_LITE = r'''<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>JARVIS LITE v1.0 — TRỢ LÝ AI WINDOWS</title>
<style>
  :root{--bg:#060b16;--panel:rgba(12,21,38,.9);--border:rgba(0,245,212,.25);--cyan:#00f5d4;--sky:#38bdf8;--amber:#fbbf24;--text:#e2e8f0;--muted:#94a3b8}
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:"Segoe UI",system-ui,sans-serif;background:radial-gradient(circle at 12% 10%,#0e2240 0%,#060b16 60%);color:var(--text);height:100vh;overflow:hidden;display:flex;flex-direction:column}
  .topbar{height:52px;padding:0 18px;background:rgba(7,13,25,.95);border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between}
  .brand{display:flex;align-items:center;gap:10px;font-weight:800;color:var(--cyan);font-size:15px}
  .dot{width:9px;height:9px;border-radius:50%;background:var(--cyan);box-shadow:0 0 10px var(--cyan)}
  .pills{display:flex;gap:8px;font-size:12px}
  .pill{background:#0f1d35;border:1px solid rgba(56,189,248,.3);padding:4px 10px;border-radius:999px;color:#bae6fd}
  .main{flex:1;display:grid;grid-template-columns:225px 1fr 295px;min-height:0}
  .side{background:rgba(7,13,25,.84);border-right:1px solid var(--border);padding:12px;display:flex;flex-direction:column;gap:7px;overflow-y:auto}
  .nav{width:100%;text-align:left;padding:10px 12px;border-radius:10px;border:1px solid transparent;background:transparent;color:var(--text);cursor:pointer;font-weight:600;font-size:13px}
  .nav:hover{background:rgba(0,245,212,.08);border-color:rgba(0,245,212,.25)}
  .nav.active{background:rgba(0,245,212,.15);border-color:var(--cyan);color:var(--cyan)}
  .sec{margin-top:10px;padding-top:10px;border-top:1px solid rgba(148,163,184,.16)}
  .stitle{font-size:11px;color:var(--muted);text-transform:uppercase;margin-bottom:6px;letter-spacing:.6px}
  .qbtn{width:100%;padding:8px 10px;margin-bottom:6px;border-radius:8px;border:1px solid rgba(56,189,248,.22);background:#0f1c32;color:#e2e8f0;cursor:pointer;font-size:12px;text-align:left}
  .qbtn:hover{border-color:var(--cyan);color:var(--cyan)}
  .center{display:flex;flex-direction:column;min-height:0}
  .tab{display:none;flex:1;flex-direction:column;min-height:0}.tab.active{display:flex}
  .stream{flex:1;overflow-y:auto;padding:18px 22px;display:flex;flex-direction:column;gap:13px}
  .msg{max-width:88%;padding:12px 15px;border-radius:14px;line-height:1.55;font-size:14px;word-break:break-word}
  .msg.user{align-self:flex-end;background:linear-gradient(135deg,#0d3b66,#144e6b);border:1px solid rgba(56,189,248,.4)}
  .msg.ai{align-self:flex-start;background:var(--panel);border:1px solid var(--border)}
  .mhead{display:flex;justify-content:space-between;font-size:11px;color:var(--muted);margin-bottom:5px;gap:10px}
  .badge{padding:2px 7px;border-radius:6px;background:rgba(0,245,212,.14);color:var(--cyan);font-weight:700}
  .tl{margin:4px 0 8px;padding:7px 10px;border-radius:8px;background:#071020;border:1px solid rgba(56,189,248,.2);font-size:12px;color:#93c5fd}
  .cwrap{margin:8px 0;border-radius:9px;overflow:hidden;border:1px solid rgba(56,189,248,.3);background:#030712}
  .cbar{display:flex;justify-content:space-between;padding:5px 10px;background:#0f1b2e;font-size:11px;color:var(--sky)}
  .cbar button{background:#1e3a5f;color:#fff;border:none;border-radius:5px;padding:2px 8px;cursor:pointer;font-size:11px}
  pre{padding:10px 12px;overflow-x:auto;font-family:Consolas,monospace;font-size:12.5px;color:#a7f3d0}
  code.inline{background:rgba(56,189,248,.16);color:#7dd3fc;padding:1px 5px;border-radius:5px;font-family:Consolas,monospace;font-size:12.5px}
  .comp{padding:12px 18px;border-top:1px solid var(--border);background:rgba(7,13,25,.95);display:flex;gap:8px;align-items:center}
  .comp input{flex:1;background:#0f1d35;border:1px solid rgba(0,245,212,.3);color:#fff;padding:11px 14px;border-radius:11px;font-size:14px;outline:none}
  .bsend{background:var(--cyan);color:#041019;border:none;padding:11px 17px;border-radius:10px;font-weight:800;cursor:pointer}
  .bsub{background:#1e293b;color:#e2e8f0;border:1px solid rgba(148,163,184,.25);padding:10px 12px;border-radius:10px;cursor:pointer}
  .right{background:rgba(7,13,25,.84);border-left:1px solid var(--border);padding:12px;overflow-y:auto;display:flex;flex-direction:column;gap:10px}
  .card{background:rgba(15,25,45,.92);border:1px solid rgba(56,189,248,.22);border-radius:11px;padding:11px}
  .card h3{font-size:11.5px;color:var(--cyan);text-transform:uppercase;margin-bottom:7px;letter-spacing:.5px}
  .kv{font-size:12.5px;color:#cbd5e1;margin:4px 0;line-height:1.45}
  .pad{padding:18px 22px;overflow-y:auto;flex:1}
  .item{background:#091324;border:1px solid rgba(148,163,184,.16);border-radius:8px;padding:9px 11px;margin-bottom:7px;font-size:13px;display:flex;justify-content:space-between;gap:8px}
  .del{background:transparent;border:none;color:#f87171;cursor:pointer;font-weight:800}
  .rform{display:flex;gap:8px;margin-bottom:12px}
  .rform input{flex:1;background:#0f1d35;border:1px solid rgba(0,245,212,.28);color:#fff;padding:9px 12px;border-radius:9px}
  .guide-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:10px 0 16px}
  .gcard{background:#0c172b;border:1px solid rgba(56,189,248,.22);border-radius:10px;padding:12px;cursor:pointer;transition:.15s}
  .gcard:hover{border-color:var(--cyan);transform:translateY(-1px)}
  .gcard b{color:var(--cyan);display:block;margin-bottom:4px;font-size:13px}
  .gcard span{color:#cbd5e1;font-size:12px}
</style>
</head>
<body>
  <div class="topbar">
    <div class="brand"><div class="dot"></div> JARVIS LITE v1.0 // WINDOWS AI ASSISTANT</div>
    <div class="pills">
      <span class="pill" id="p-mdl">🧠 ...</span>
      <span class="pill" id="p-hw">💻 CPU/RAM</span>
      <span class="pill" style="border-color:rgba(251,191,36,.4);color:#fde68a">✨ Edition: LITE</span>
    </div>
  </div>
  <div class="main">
    <aside class="side">
      <button class="nav active" onclick="sw('chat',this)">💬 Trò chuyện & Ra lệnh</button>
      <button class="nav" onclick="sw('guide',this)">📖 Hướng dẫn & Lệnh mẫu</button>
      <button class="nav" onclick="sw('memory',this)">🧬 Trí nhớ của Jarvis</button>
      <button class="nav" onclick="sw('reminders',this)">⏰ Lịch nhắc chủ động</button>
      <div class="sec">
        <div class="stitle">Thử nhanh 1-Click</div>
        <button class="qbtn" onclick="go('Thời tiết hôm nay thế nào, có mưa không?')">🌤️ Xem thời tiết live</button>
        <button class="qbtn" onclick="go('Dịch và giải thích đoạn văn bản mình vừa copy')">🌐 Dịch đoạn vừa copy</button>
        <button class="qbtn" onclick="go('Tóm tắt trang hoặc cửa sổ mình đang mở trên màn hình')">👁️ Hiểu màn hình đang mở</button>
        <button class="qbtn" onclick="go('1 phút nữa nhắc mình đứng dậy uống nước')">⏰ Thử hẹn nhắc 1 phút</button>
        <button class="qbtn" onclick="go('Kiểm tra dung lượng trống các ổ đĩa')">💾 Kiểm tra ổ đĩa</button>
      </div>
      <div class="sec">
        <div class="stitle">Tiện ích</div>
        <button class="qbtn" onclick="act('stop_speak')">🔇 Ngắt giọng đọc ngay</button>
        <button class="qbtn" onclick="act('clear_session')">🧹 Làm mới khung chat</button>
      </div>
    </aside>

    <section class="center">
      <div id="tab-chat" class="tab active">
        <div id="stream" class="stream"></div>
        <div id="img-bar" style="display:none;padding:6px 18px;background:#0a1628;border-top:1px solid rgba(0,245,212,.2);font-size:12px;color:#6ee7b7;justify-content:space-between">
          <span id="img-name">🖼️ Đã đính kèm ảnh</span>
          <button class="del" onclick="clearImg()">✖ Bỏ</button>
        </div>
        <div class="comp" ondragover="event.preventDefault()" ondrop="dropImg(event)">
          <input type="file" id="fimg" accept="image/*" style="display:none" onchange="pickImg(this)" />
          <button class="bsub" title="Đính kèm hoặc kéo thả ảnh" onclick="document.getElementById('fimg').click()">📎</button>
          <button class="bsub" id="bmic" title="Nói giọng tiếng Việt" onclick="recVoice()">🎙️</button>
          <input id="inp" placeholder="Hỏi bất cứ điều gì, kéo thả ảnh, hoặc bấm 🎙️ để nói..." onkeydown="if(event.key==='Enter') send()" />
          <label style="font-size:12px;color:#94a3b8;display:flex;align-items:center;gap:4px"><input type="checkbox" id="tts" checked /> 🔊</label>
          <button class="bsend" onclick="send()">⚡ Gửi</button>
        </div>
      </div>

      <div id="tab-guide" class="tab">
        <div class="pad">
          <h2 style="color:var(--cyan);font-size:17px;margin-bottom:6px">📖 Hướng Dẫn Sử Dụng Nhanh — Jarvis Lite v1.0</h2>
          <p style="color:#94a3b8;font-size:13px;margin-bottom:12px">Bấm trực tiếp vào bất kỳ thẻ ví dụ nào bên dưới để Jarvis chạy thử ngay lập tức!</p>
          <div class="guide-grid">
            <div class="gcard" onclick="go('Tóm tắt cửa sổ mình đang mở trên màn hình')"><b>👁️ Hiểu ý nửa lời</b><span>Tự đọc cửa sổ đang mở & Clipboard khi bạn hỏi "cái này", "đoạn vừa copy", "lỗi này".</span></div>
            <div class="gcard" onclick="go('Dịch đoạn vừa copy sang tiếng Việt')"><b>🌐 Dịch tức thì</b><span>Chỉ cần Ctrl+C đoạn tiếng Anh bất kỳ rồi nhờ Jarvis dịch & giải thích.</span></div>
            <div class="gcard" onclick="go('15 phút nữa nhắc mình nghỉ mắt')"><b>⏰ Nhắc việc chủ động</b><span>Tự bắt mốc giờ tiếng Việt, tới giờ tự bật thông báo & đọc ra loa.</span></div>
            <div class="gcard" onclick="go('Mở YouTube nhạc lofi chill')"><b>🚀 Mở nhanh App & Web</b><span>Mở YouTube, Chrome, Word, Excel, Notepad hoặc tìm file trong máy chỉ bằng 1 câu nói.</span></div>
            <div class="gcard" onclick="go('Tạo mã QR cho https://github.com')"><b>📱 Tạo mã QR & Tiện ích</b><span>Tạo mã QR tức thì, đọc file PDF/Word, tóm tắt video YouTube, dọn rác tạm ổ C.</span></div>
            <div class="gcard" onclick="go('Nhớ giúp mình là mình thích làm việc buổi tối và dùng Python')"><b>🧬 Trí nhớ dài hạn</b><span>Càng dùng lâu càng hiểu bạn, tự cập nhật khi bạn thay đổi sở thích.</span></div>
          </div>
          <div class="card" style="margin-bottom:12px">
            <h3>⌨️ Phím tắt tiện lợi</h3>
            <div class="kv">• <b>Ctrl + Alt + J</b>: Mở nhanh cửa sổ Jarvis Lite từ bất kỳ đâu.</div>
            <div class="kv">• <b>Ctrl + Alt + S</b>: Ngắt giọng đọc ngay lập tức.</div>
            <div class="kv">• <b>Kéo thả ảnh</b>: Thả trực tiếp ảnh bài tập, hóa đơn, lỗi code vào ô chat để AI phân tích.</div>
          </div>
          <div class="card" style="border-color:rgba(251,191,36,.35)">
            <h3 style="color:#fbbf24">🚀 Lộ trình nâng cấp sắp tới (v1.2 -> v2.0 Pro)</h3>
            <div class="kv">• <b>v1.2</b>: Điều khiển PC & nhận ảnh/tin nhắn từ xa qua <b>Telegram</b>.</div>
            <div class="kv">• <b>v1.5</b>: Điều khiển không chạm bằng <b>Cử chỉ tay (Air Gesture)</b> & Nói chuyện liên tục.</div>
            <div class="kv">• <b>v2.0 Pro</b>: Bảo mật khuôn mặt 3D chống ảnh, Visual OS Agent tự bấm chuột/phím & Tự học kỹ năng mới.</div>
          </div>
        </div>
      </div>

      <div id="tab-memory" class="tab">
        <div class="pad">
          <h2 style="color:var(--cyan);font-size:16px;margin-bottom:10px">🧬 Trí Nhớ Dài Hạn (Chỉ lưu cục bộ trên máy bạn)</h2>
          <div class="rform"><input id="minp" placeholder="Ví dụ: Mình là sinh viên IT, thích giao diện tối..." onkeydown="if(event.key==='Enter') addMem()" /><button class="bsend" onclick="addMem()">+ Nhớ</button></div>
          <div id="mlist"></div>
        </div>
      </div>

      <div id="tab-reminders" class="tab">
        <div class="pad">
          <h2 style="color:var(--amber);font-size:16px;margin-bottom:10px">⏰ Lịch Nhắc Việc Chủ Động</h2>
          <div class="rform"><input id="rinp" placeholder="Ví dụ: 10 phút nữa nhắc mình nộp bài / 20h30 nhắc họp..." onkeydown="if(event.key==='Enter') addRem()" /><button class="bsend" onclick="addRem()">+ Hẹn giờ</button></div>
          <div id="rlist"></div>
        </div>
      </div>
    </section>

    <aside class="right">
      <div class="card">
        <h3>👁️ Ngữ cảnh đang cảm nhận</h3>
        <div class="kv" id="a-app"><b>App:</b> ...</div>
        <div class="kv" id="a-title"><b>Cửa sổ:</b> ...</div>
        <div class="kv" id="a-clip" style="color:#94a3b8;font-size:11.5px"><b>Clipboard:</b> ...</div>
      </div>
      <div class="card">
        <h3>⏰ Nhắc việc sắp tới</h3>
        <div id="srem" class="kv">Chưa có lịch hẹn nào</div>
      </div>
      <div class="card">
        <h3>🔐 Quyền riêng tư & An toàn</h3>
        <div class="kv">• API Key mã hóa <b>Windows DPAPI</b>.</div>
        <div class="kv">• Bản Lite <b>không chạy lệnh hệ thống ẩn</b>, an toàn tuyệt đối với Windows Defender.</div>
      </div>
    </aside>
  </div>

<script>
let rendered = -1, imgB64 = null;
const esc = s => String(s||"").replace(/[&<>"]/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));

function md(src){
  const blks = [];
  let t = String(src||"").replace(/```(\w*)\n([\s\S]*?)```/g,(_,l,c)=>{const i=blks.length;blks.push({l:l||'code',c:c.trimEnd()});return `@@CB${i}@@`;});
  t = esc(t).replace(/`([^`]+)`/g,'<code class="inline">$1</code>').replace(/\*\*([^*]+)\*\*/g,'<b>$1</b>');
  t = t.replace(/((?:^\|.+\|$\n?){2,})/gm, tbl=>{
    const rows = tbl.trim().split('\n').filter(r=>!/^\|[\s:\-|]+\|$/.test(r));
    if(!rows.length) return tbl;
    return '<table style="border-collapse:collapse;margin:8px 0;width:100%;font-size:13px">' + rows.map((r,i)=>{
      const cells=r.replace(/^\||\|$/g,'').split('|').map(c=>c.trim());
      const tag=i===0?'th':'td', st=i===0?'background:#0f2138;color:#00f5d4;padding:6px;border:1px solid #1e3a5f':'padding:5px;border:1px solid #1e293b';
      return '<tr>'+cells.map(c=>`<${tag} style="${st}">${c}</${tag}>`).join('')+'</tr>';
    }).join('') + '</table>';
  });
  t = t.replace(/\n/g,'<br/>');
  blks.forEach((b,i)=>{
    const id='c'+Math.random().toString(36).slice(2,8);
    t = t.replace(`@@CB${i}@@`,`<div class="cwrap"><div class="cbar"><span>${esc(b.l)}</span><button onclick="navigator.clipboard.writeText(document.getElementById('${id}').innerText)">📋 Copy</button></div><pre id="${id}">${esc(b.c)}</pre></div>`);
  });
  return t;
}

function sw(name, btn){
  document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));
  document.querySelectorAll('.nav').forEach(x=>x.classList.remove('active'));
  document.getElementById('tab-'+name).classList.add('active');
  if(btn) btn.classList.add('active');
  refresh();
}
function go(txt){ sw('chat', document.querySelectorAll('.nav')[0]); document.getElementById('inp').value=txt; send(); }
function setImg(f){ if(!f||!f.type.startsWith('image/'))return; const r=new FileReader(); r.onload=()=>{imgB64=String(r.result||'').split(',')[1]||null;document.getElementById('img-name').textContent='🖼️ Đã đính kèm: '+f.name;document.getElementById('img-bar').style.display='flex';}; r.readAsDataURL(f); }
function pickImg(i){ if(i.files&&i.files[0]) setImg(i.files[0]); i.value=''; }
function dropImg(e){ e.preventDefault(); if(e.dataTransfer&&e.dataTransfer.files[0]) setImg(e.dataTransfer.files[0]); }
function clearImg(){ imgB64=null; document.getElementById('img-bar').style.display='none'; }

function bubble(role, text, meta, tl){
  const st=document.getElementById('stream'), d=document.createElement('div');
  d.className='msg '+role;
  d.innerHTML=`<div class="mhead"><span>${role==='user'?'👤 Bạn':'🤖 JARVIS LITE'} ${meta?`<span class="badge">${esc(meta)}</span>`:''}</span></div>${tl||''}<div class="mbody">${md(text)}</div>`;
  st.appendChild(d); st.scrollTop=st.scrollHeight; return d;
}

async function recVoice(){
  const b=document.getElementById('bmic'); b.textContent='🔴'; b.disabled=true;
  try{ const r=await fetch('/api/voice',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'}); const d=await r.json(); if(d.text){document.getElementById('inp').value=d.text;send();} else alert(d.error||'Chưa nghe rõ!'); }
  finally{ b.textContent='🎙️'; b.disabled=false; }
}

async function send(){
  const i=document.getElementById('inp'), txt=i.value.trim(); if(!txt) return; i.value='';
  bubble('user', txt);
  const ai=bubble('ai','Đang suy nghĩ...','THINKING','<div class="tl">🧠 Đang phân tích yêu cầu...</div>');
  const r=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:txt,speak:document.getElementById('tts').checked,image_b64:imgB64})});
  clearImg();
  const {job_id}=await r.json();
  const tm=setInterval(async()=>{
    const jr=await fetch('/api/job/'+job_id), jd=await jr.json();
    if(jd.events&&jd.events.length) ai.querySelector('.tl').innerHTML=jd.events.map(e=>`<div>${esc(e)}</div>`).join('');
    if(jd.done){
      clearInterval(tm);
      const res=jd.result||{};
      ai.querySelector('.mhead').innerHTML=`<span>🤖 JARVIS LITE <span class="badge">${esc(res.route||'LITE')} • ${res.elapsed_ms||0}ms</span></span>`;
      ai.querySelector('.mbody').innerHTML=md(res.reply||jd.error||'Xong!');
      document.getElementById('stream').scrollTop=document.getElementById('stream').scrollHeight;
      rendered=-1; refresh();
    }
  },320);
}

async function addMem(){ const i=document.getElementById('minp'); if(!i.value.trim())return; await fetch('/api/mem/add',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({content:i.value.trim()})}); i.value=''; refresh(); }
async function delMem(id){ await fetch('/api/mem/del',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id})}); refresh(); }
async function addRem(){ const i=document.getElementById('rinp'); if(!i.value.trim())return; await fetch('/api/rem/add',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:i.value.trim()})}); i.value=''; refresh(); }
async function delRem(id){ await fetch('/api/rem/del',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id})}); refresh(); }
async function act(a){ await fetch('/api/act',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:a})}); if(a==='clear_session'){rendered=0;document.getElementById('stream').innerHTML='';} refresh(); }

async function refresh(){
  try{
    const s=await (await fetch('/api/state')).json();
    document.getElementById('p-mdl').textContent='🧠 '+s.fast_model;
    document.getElementById('p-hw').textContent=`💻 CPU ${s.cpu}% | RAM ${s.ram}%`;
    document.getElementById('a-app').innerHTML=`<b>App:</b> ${esc(s.ambient.app)}`;
    document.getElementById('a-title').innerHTML=`<b>Cửa sổ:</b> ${esc(s.ambient.title)}`;
    document.getElementById('a-clip').innerHTML=`<b>Clipboard:</b> ${esc((s.ambient.clipboard||'(trống)').slice(0,110))}`;
    const rems=s.reminders||[];
    document.getElementById('srem').innerHTML=rems.length?rems.slice(0,4).map(x=>`<div>⏰ <b>${esc(x.due_str)}</b>: ${esc(x.task)}</div>`).join(''):'Chưa có lịch hẹn nào';
    document.getElementById('rlist').innerHTML=rems.length?rems.map(x=>`<div class="item"><span>⏰ <b>${esc(x.due_str)}</b> — ${esc(x.task)}</span><button class="del" onclick="delRem('${esc(x.id)}')">✖</button></div>`).join(''):'<div style="color:#64748b">Chưa có lịch nhắc nào.</div>';
    const fs=(s.facts||[]).slice().reverse();
    document.getElementById('mlist').innerHTML=fs.length?fs.map(f=>`<div class="item"><span>${esc(f.content)}</span><button class="del" onclick="delMem('${esc(f.id)}')">✖</button></div>`).join(''):'<div style="color:#64748b">Chưa có ký ức nào.</div>';
    if(rendered===-1){
      const st=document.getElementById('stream'); st.innerHTML='';
      if(!s.turns.length){ bubble('ai','Chào bạn! **Jarvis Lite v1.0** đã sẵn sàng. Nếu mới dùng lần đầu, bấm vào mục **📖 Hướng dẫn & Lệnh mẫu** bên trái để thử các tính năng cực hay chỉ bằng 1 click nhé!','READY'); }
      else { s.turns.forEach(t=>{ bubble('user',t.user); bubble('ai',t.assistant,(t.meta||{}).route||'LITE'); }); }
      rendered=s.turns.length;
    }
  }catch(e){}
}
refresh(); setInterval(refresh, 3500);
</script>
</body>
</html>
'''


class _LiteHandler(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def _json(self, obj, code=200):
        raw = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def _body(self):
        n = int(self.headers.get("Content-Length", "0") or 0)
        return json.loads(self.rfile.read(n).decode("utf-8")) if n > 0 else {}

    def do_GET(self):
        p = self.path.split("?")[0]
        if p == "/":
            raw = HTML_LITE.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)
        elif p == "/api/state":
            fm, _ = get_lite_kernel().get_model_pair()
            self._json({
                "fast_model": fm,
                "cpu": psutil.cpu_percent(interval=None),
                "ram": psutil.virtual_memory().percent,
                "ambient": get_ambient_monitor().get_snapshot(refresh=False),
                "facts": get_semantic_memory().get_all().get("facts", []),
                "reminders": get_scheduler().list_pending(),
                "turns": get_session_bus().get_recent_turns(14),
            })
        elif p.startswith("/api/job/"):
            jid = p.split("/api/job/", 1)[1]
            with _JOBS_LOCK:
                self._json(dict(_JOBS.get(jid, {"done": True, "error": "Không tìm thấy phiên."})))
        else:
            self.send_response(404); self.end_headers()

    def do_POST(self):
        p, b = self.path.split("?")[0], self._body()
        if p == "/api/chat":
            jid = uuid.uuid4().hex[:10]
            with _JOBS_LOCK:
                _JOBS[jid] = {"done": False, "events": [], "result": None, "error": None}
            def _w():
                try:
                    res = get_lite_kernel().handle(
                        str(b.get("text") or ""),
                        source="lite_ui",
                        attached_image_b64=b.get("image_b64") or None,
                        on_event=lambda e: _JOBS[jid]["events"].append(str(e.get("message") or "")),
                    )
                    if b.get("speak") and res.get("spoken"):
                        get_speaker().speak_async(res["spoken"], rate="+12%")
                    with _JOBS_LOCK:
                        _JOBS[jid]["result"] = res; _JOBS[jid]["done"] = True
                except Exception as e:
                    with _JOBS_LOCK:
                        _JOBS[jid]["error"] = str(e); _JOBS[jid]["done"] = True
            threading.Thread(target=_w, daemon=True).start()
            self._json({"job_id": jid})
        elif p == "/api/voice":
            try:
                import numpy as np, sounddevice as sd, speech_recognition as sr
                fs = 16000
                rec = sd.rec(int(5.0 * fs), samplerate=fs, channels=1, dtype="int16")
                sd.wait()
                peak = int(np.max(np.abs(rec)))
                if peak < 60:
                    self._json({"error": "Không nghe thấy tiếng từ Micro."}); return
                if peak < 8000:
                    rec = np.clip(rec.astype(np.float32) * (15000.0 / peak), -32768, 32767).astype(np.int16)
                txt = sr.Recognizer().recognize_google(sr.AudioData(rec.tobytes(), fs, 2), language="vi-VN").strip()
                self._json({"text": txt})
            except Exception as e:
                self._json({"error": f"Nghe chưa rõ ({e})"})
        elif p == "/api/mem/add":
            get_semantic_memory().upsert_fact(str(b.get("content") or ""), category="user", importance=0.9)
            self._json({"ok": True})
        elif p == "/api/mem/del":
            get_semantic_memory().delete_fact(str(b.get("id") or "")); self._json({"ok": True})
        elif p == "/api/rem/add":
            t = str(b.get("text") or "").strip()
            get_scheduler().add_from_text(t if "nhắc" in t.lower() else f"nhắc tao {t}")
            self._json({"ok": True})
        elif p == "/api/rem/del":
            get_scheduler().delete(str(b.get("id") or "")); self._json({"ok": True})
        elif p == "/api/act":
            a = b.get("action")
            if a == "stop_speak": get_speaker().stop()
            elif a == "clear_session": get_session_bus().clear()
            self._json({"ok": True})
        else:
            self.send_response(404); self.end_headers()


def ensure_lite_server(port: int = 8792) -> int:
    if _SRV["port"]:
        return int(_SRV["port"])
    for cand in (port, 8793, 8794, 0):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(("127.0.0.1", cand))
                chosen = int(s.getsockname()[1])
                break
        except OSError:
            continue
    httpd = ThreadingHTTPServer(("127.0.0.1", chosen), _LiteHandler)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    _SRV["port"] = chosen
    return chosen


def open_lite_window() -> str:
    url = f"http://127.0.0.1:{ensure_lite_server()}/"
    for br in (
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        shutil.which("msedge"),
        shutil.which("chrome"),
    ):
        if br and os.path.isfile(br):
            subprocess.Popen([br, f"--app={url}", "--window-size=1220,780"], creationflags=0x08000000)
            return url
    webbrowser.open(url)
    return url

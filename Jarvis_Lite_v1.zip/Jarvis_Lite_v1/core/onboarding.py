﻿import json
import os
import threading
import tkinter as tk
from tkinter import messagebox, ttk
import urllib.request
import webbrowser

from core.secret_dpapi import load_config_decrypted, protect_str

CONFIG_PATH = "config.json"
EXAMPLE_PATH = "config.example.json"
DEFAULT_ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions"


def has_valid_api_key() -> bool:
    if not os.path.exists(CONFIG_PATH):
        return False
    cfg = load_config_decrypted(CONFIG_PATH)
    key = str(cfg.get("vlm", {}).get("api_key") or "").strip()
    return len(key) >= 20 and not key.startswith("***")


def _probe_and_pick_models(api_key: str) -> tuple[bool, str, str, str]:
    """Kiểm tra API Key trực tiếp với Google AI Studio & chọn cặp model hoạt động tốt nhất."""
    key = api_key.strip()
    if len(key) < 20:
        return False, "API Key quá ngắn (phải bắt đầu bằng AIza...).", "", ""
    try:
        with urllib.request.urlopen(f"https://generativelanguage.googleapis.com/v1beta/models?key={key}", timeout=15) as r:
            data = json.loads(r.read().decode("utf-8"))
        avail = [
            str(m.get("name", "")).replace("models/", "")
            for m in data.get("models", [])
            if "generateContent" in (m.get("supportedGenerationMethods") or [])
        ]
    except Exception as e:
        return False, f"Không kết nối được Google AI Studio (kiểm tra lại Key hoặc mạng): {e}", "", ""

    fast_pick = next((m for m in ("gemini-2.5-flash-lite", "gemini-2.5-flash", "gemini-2.0-flash", "gemini-3.5-flash-lite") if m in avail), None)
    pro_pick = next((m for m in ("gemini-2.5-pro", "gemini-2.5-flash", "gemini-3.5-flash", "gemini-2.0-flash") if m in avail), None)
    if not fast_pick:
        fast_pick = next((m for m in avail if "gemini" in m.lower() and "embedding" not in m.lower()), "gemini-2.5-flash")
    if not pro_pick:
        pro_pick = fast_pick

    # Test gọi thật 1 câu siêu ngắn
    try:
        payload = {"model": fast_pick, "max_tokens": 10, "messages": [{"role": "user", "content": "OK"}]}
        req = urllib.request.Request(
            DEFAULT_ENDPOINT,
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json", "Authorization": f"Bearer {key}"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=15) as resp:
            body = json.loads(resp.read().decode("utf-8"))
            if body.get("choices"):
                return True, f"Kết nối thành công! (Fast: {fast_pick} | Pro: {pro_pick})", fast_pick, pro_pick
    except Exception as e:
        return False, f"Key hợp lệ nhưng gọi model '{fast_pick}' bị lỗi: {e}", "", ""
    return False, "API không phản hồi hợp lệ.", "", ""


def run_onboarding_wizard() -> bool:
    """Hiện bảng thiết lập lần đầu trực quan cho người dùng mới. Trả về True nếu cài xong."""
    done = {"ok": False}
    root = tk.Tk()
    root.title("🚀 Thiết Lập Lần Đầu — JARVIS LITE v1.0")
    root.geometry("560x495")
    root.resizable(False, False)
    root.configure(bg="#060c18")

    # Căn giữa màn hình
    root.update_idletasks()
    x = (root.winfo_screenwidth() - 560) // 2
    y = (root.winfo_screenheight() - 495) // 2
    root.geometry(f"+{x}+{y}")

    box = tk.Frame(root, bg="#0b1324", padx=22, pady=18, highlightbackground="#00f5d4", highlightthickness=1)
    box.pack(fill="both", expand=True, padx=14, pady=14)

    tk.Label(box, text="🌌 CHÀO MỪNG ĐẾN VỚI JARVIS LITE v1.0", font=("Segoe UI", 13, "bold"), bg="#0b1324", fg="#00f5d4").pack(anchor="w")
    tk.Label(
        box,
        text="Trợ lý AI trên máy tính Windows — Hiểu màn hình, đọc Clipboard, nhắc việc & 12+ công cụ tiện ích.\nChỉ mất 30 giây để kích hoạt bằng Google Gemini API Key (hoàn toàn miễn phí):",
        font=("Segoe UI", 9), bg="#0b1324", fg="#cbd5e1", justify="left", wraplength=490,
    ).pack(anchor="w", pady=(6, 12))

    # Bước 1: Lấy Key
    f1 = tk.Frame(box, bg="#101d35", padx=12, pady=10)
    f1.pack(fill="x", pady=(0, 10))
    tk.Label(f1, text="Bước 1: Lấy Google AI Studio API Key miễn phí", font=("Segoe UI", 9, "bold"), bg="#101d35", fg="#38bdf8").pack(anchor="w")
    tk.Label(f1, text="Bấm nút bên dưới -> Đăng nhập Gmail -> Chọn 'Create API Key' -> Copy mã bắt đầu bằng AIza...", font=("Segoe UI", 8), bg="#101d35", fg="#94a3b8", wraplength=460, justify="left").pack(anchor="w", pady=(2, 6))
    tk.Button(
        f1, text="🌐 Mở trang lấy API Key miễn phí (Google AI Studio)", font=("Segoe UI", 9, "bold"),
        bg="#1e3a5f", fg="#bae6fd", relief="flat", padx=12, pady=5, cursor="hand2",
        command=lambda: webbrowser.open("https://aistudio.google.com/app/apikey"),
    ).pack(anchor="w")

    # Bước 2: Dán Key
    tk.Label(box, text="Bước 2: Dán API Key của bạn vào đây (sẽ được mã hóa Windows DPAPI an toàn):", font=("Segoe UI", 9, "bold"), bg="#0b1324", fg="#f8fafc").pack(anchor="w")
    key_ent = tk.Entry(box, bg="#112036", fg="#ffffff", insertbackground="#00f5d4", font=("Consolas", 10), relief="flat", show="*")
    key_ent.pack(fill="x", ipady=7, pady=(4, 10))

    # Bước 3: Cá nhân hóa tên & phong cách
    row3 = tk.Frame(box, bg="#0b1324")
    row3.pack(fill="x", pady=(0, 10))

    c1 = tk.Frame(row3, bg="#0b1324")
    c1.pack(side="left", fill="x", expand=True, padx=(0, 8))
    tk.Label(c1, text="Tên Jarvis gọi bạn:", font=("Segoe UI", 9, "bold"), bg="#0b1324", fg="#f8fafc").pack(anchor="w")
    name_ent = tk.Entry(c1, bg="#112036", fg="#ffffff", insertbackground="#00f5d4", font=("Segoe UI", 9), relief="flat")
    name_ent.insert(0, "bạn")
    name_ent.pack(fill="x", ipady=5, pady=(3, 0))

    c2 = tk.Frame(row3, bg="#0b1324")
    c2.pack(side="right", fill="x", expand=True, padx=(8, 0))
    tk.Label(c2, text="Phong cách nói chuyện:", font=("Segoe UI", 9, "bold"), bg="#0b1324", fg="#f8fafc").pack(anchor="w")
    persona_map = {
        "Thân thiện & Tự nhiên (Mình - Bạn)": "friendly",
        "Lịch sự & Chuyên nghiệp (Trợ lý - Bạn)": "professional",
        "Bạn thân lầy lội (Tao - Mày)": "bestie",
    }
    persona_cb = ttk.Combobox(c2, values=list(persona_map.keys()), state="readonly")
    persona_cb.current(0)
    persona_cb.pack(fill="x", ipady=2, pady=(3, 0))

    status_lbl = tk.Label(box, text="💡 Mọi dữ liệu & API Key chỉ lưu cục bộ trên máy bạn, không gửi về bên thứ ba.", font=("Segoe UI", 8), bg="#0b1324", fg="#94a3b8", wraplength=490, justify="left")
    status_lbl.pack(anchor="w", pady=(2, 10))

    btn_save = tk.Button(
        box, text="⚡ Kiểm tra & Kích hoạt Jarvis Lite", font=("Segoe UI", 10, "bold"),
        bg="#00f5d4", fg="#041019", relief="flat", padx=16, pady=9, cursor="hand2",
    )
    btn_save.pack(fill="x")

    def _on_activate():
        raw_k = key_ent.get().strip()
        if not raw_k:
            status_lbl.config(text="⚠️ Bạn chưa dán API Key kìa!", fg="#f87171")
            return
        btn_save.config(state="disabled", text="⏳ Đang kiểm tra kết nối với Google AI...")
        status_lbl.config(text="⏳ Đang xác thực API Key & dò model tốt nhất...", fg="#fbbf24")

        def _work():
            ok, msg, fm, pm = _probe_and_pick_models(raw_k)
            if not ok:
                root.after(0, lambda: (
                    btn_save.config(state="normal", text="⚡ Kiểm tra & Kích hoạt Jarvis Lite"),
                    status_lbl.config(text=f"❌ {msg}", fg="#f87171"),
                ))
                return
            base_cfg = json.load(open(EXAMPLE_PATH, "r", encoding="utf-8-sig")) if os.path.exists(EXAMPLE_PATH) else {}
            vlm = base_cfg.setdefault("vlm", {})
            vlm["endpoint"] = DEFAULT_ENDPOINT
            vlm["model"] = fm
            vlm["fast_model"] = fm
            vlm["pro_model"] = pm
            vlm["api_key"] = protect_str(raw_k)
            base_cfg["profile"] = {
                "user_name": name_ent.get().strip() or "bạn",
                "persona": persona_map.get(persona_cb.get(), "friendly"),
            }
            with open(CONFIG_PATH, "w", encoding="utf-8") as f:
                json.dump(base_cfg, f, ensure_ascii=False, indent=2)
            done["ok"] = True
            root.after(0, lambda: (
                messagebox.showinfo("Jarvis Lite v1.0", f"✅ {msg}\n\nAPI Key đã được mã hóa an toàn bằng Windows DPAPI. Bấm OK để mở Jarvis ngay!"),
                root.destroy(),
            ))

        threading.Thread(target=_work, daemon=True).start()

    btn_save.config(command=_on_activate)
    root.mainloop()
    return done["ok"]

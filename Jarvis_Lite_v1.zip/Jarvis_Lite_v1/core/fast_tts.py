import asyncio
import concurrent.futures
import ctypes
import os
import re
import tempfile
import threading
import time
import edge_tts
from gtts import gTTS


def _mci(cmd: str) -> tuple[int, str]:
    buf = ctypes.create_unicode_buffer(256)
    rc = ctypes.windll.winmm.mciSendStringW(cmd, buf, 255, None)
    return int(rc), buf.value.strip()


def clean_speech_text(text: str, max_chars: int = 2500) -> str:
    if not text:
        return ""
    # Bỏ khối code dài để khỏi đọc ngoặc nhọn/code rối tai
    s = re.sub(r"```.*?```", " (tao đã để phần code trên màn hình nha) ", text, flags=re.S)
    s = re.sub(r"https?://\S+", "", s)
    s = re.sub(r"[*_`#~>\[\]|]", " ", s)
    s = re.sub(
        r"[^\w\s.,!?;:()\-\/%àáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹđ"
        r"ÀÁẠẢÃÂẦẤẬẨẪĂẰẮẶẲẴÈÉẸẺẼÊỀẾỆỂỄÌÍỊỈĨÒÓỌỎÕÔỒỐỘỔỖƠỜỚỢỞỠÙÚỤỦŨƯỪỨỰỬỮỲÝỴỶỸĐ]",
        " ", s,
    )
    s = re.sub(r"\s+", " ", s).strip()
    return s[:max_chars]


def split_for_pipeline(text: str) -> list[str]:
    """Tách câu thông minh: đoạn 1 thật gọn (~85 ký tự) để phát ngay sau ~0.35s, các đoạn sau nối liền 0ms."""
    clean = clean_speech_text(text)
    if not clean:
        return []

    raw_parts = [p.strip() for p in re.split(r"(?<=[.!?;:\n])\s+", clean) if p.strip()]
    # Nếu câu đầu tiên quá dài -> tách nhẹ ở dấu phẩy để cất tiếng ngay lập tức
    if raw_parts and len(raw_parts[0]) > 105:
        first = raw_parts[0]
        cut = first.find(", ", 38, 105)
        if cut != -1:
            raw_parts = [first[: cut + 1].strip(), first[cut + 1 :].strip()] + raw_parts[1:]

    chunks: list[str] = []
    for idx, part in enumerate(raw_parts):
        if len(part) > 220:
            # Bẻ câu quá dài theo dấu phẩy hoặc khoảng trắng
            while len(part) > 210:
                sp = part.rfind(", ", 80, 210)
                if sp == -1:
                    sp = part.rfind(" ", 100, 210)
                if sp == -1:
                    sp = 200
                chunks.append(part[: sp + 1].strip())
                part = part[sp + 1 :].strip()
            if part:
                chunks.append(part)
            continue

        if idx == 0 or not chunks:
            chunks.append(part)
        elif len(chunks) == 1:
            # Giữ nguyên chunk #1 thật ngắn để tải siêu nhanh
            chunks.append(part)
        elif len(chunks[-1]) + len(part) + 1 <= 200:
            chunks[-1] = chunks[-1] + " " + part
        else:
            chunks.append(part)

    return [c for c in chunks if c.strip()]


def _synth_chunk(chunk_text: str, out_path: str, rate: str = "+14%") -> bool:
    for _attempt in range(2):
        loop = asyncio.new_event_loop()
        try:
            asyncio.set_event_loop(loop)
            comm = edge_tts.Communicate(chunk_text, "vi-VN-NamMinhNeural", rate=rate)
            loop.run_until_complete(comm.save(out_path))
            if os.path.exists(out_path) and os.path.getsize(out_path) > 350:
                return True
        except Exception:
            time.sleep(0.15)
        finally:
            try:
                loop.close()
            except Exception:
                pass

    # Dự phòng gTTS nếu edge-tts trục trặc mạng
    try:
        gTTS(text=chunk_text, lang="vi").save(out_path)
        return os.path.exists(out_path) and os.path.getsize(out_path) > 350
    except Exception:
        return False


class PipelinedSpeaker:
    """Bộ phát giọng nói tiếng Việt đa luồng: độ trễ khởi phát ~0.35s, đọc trọn 100% câu, ngắt <50ms."""

    def __init__(self):
        self._lock = threading.Lock()
        self._seq = 0
        self._abort_evt = threading.Event()
        self._speaking = False
        self._pool = concurrent.futures.ThreadPoolExecutor(max_workers=3)

    @property
    def is_speaking(self) -> bool:
        return self._speaking

    def stop(self) -> None:
        with self._lock:
            self._seq += 1
            self._abort_evt.set()
            self._speaking = False

    def _play_mp3_same_thread(self, fpath: str, alias: str, my_seq: int) -> None:
        rc, _ = _mci(f'open "{fpath}" type mpegvideo alias {alias}')
        if rc != 0:
            return
        try:
            _, len_str = _mci(f"status {alias} length")
            max_wait = (int(len_str) / 1000.0 + 3.0) if len_str.isdigit() and int(len_str) > 0 else 45.0
            rc_p, _ = _mci(f"play {alias}")
            if rc_p != 0:
                return
            t0 = time.time()
            time.sleep(0.10)
            while not self._abort_evt.is_set() and self._seq == my_seq:
                if time.time() - t0 > max_wait:
                    break
                _, mode = _mci(f"status {alias} mode")
                m = mode.lower()
                if m in ("playing", "seeking", "not ready"):
                    time.sleep(0.04)
                else:
                    break
        finally:
            _mci(f"stop {alias}")
            _mci(f"close {alias}")

    def speak_blocking(self, text: str, rate: str = "+14%", on_first_play=None, on_start=None, on_end=None) -> None:
        chunks = split_for_pipeline(text)
        if not chunks:
            if on_first_play:
                try:
                    on_first_play()
                except Exception:
                    pass
            return

        with self._lock:
            self._seq += 1
            my_seq = self._seq
            self._abort_evt.clear()
            self._speaking = True

        if on_start:
            try:
                on_start()
            except Exception:
                pass

        # Tải song song trước các đoạn tiếp theo
        temp_files: list[str] = []
        futures: list[concurrent.futures.Future] = []
        base_id = int(time.time() * 1000) % 10000000

        for idx, ch in enumerate(chunks):
            fp = os.path.join(tempfile.gettempdir(), f"jfast_{base_id}_{my_seq}_{idx}.mp3")
            temp_files.append(fp)
            futures.append(self._pool.submit(_synth_chunk, ch, fp, rate))

        first_triggered = False
        try:
            for idx, fut in enumerate(futures):
                if self._abort_evt.is_set() or self._seq != my_seq:
                    break
                try:
                    ok = fut.result(timeout=22)
                except Exception:
                    ok = False

                if self._abort_evt.is_set() or self._seq != my_seq:
                    break

                if not first_triggered:
                    first_triggered = True
                    if on_first_play:
                        try:
                            on_first_play()
                        except Exception:
                            pass

                if ok:
                    alias = f"jf_{my_seq}_{idx}"
                    self._play_mp3_same_thread(temp_files[idx], alias, my_seq)
        finally:
            if not first_triggered and on_first_play:
                try:
                    on_first_play()
                except Exception:
                    pass
            if self._seq == my_seq:
                self._speaking = False
            if on_end:
                try:
                    on_end()
                except Exception:
                    pass
            # Dọn file tạm sạch sẽ
            for fp in temp_files:
                try:
                    if os.path.exists(fp):
                        os.remove(fp)
                except Exception:
                    pass

    def speak_async(self, text: str, rate: str = "+14%", on_first_play=None, on_start=None, on_end=None) -> None:
        self.stop()
        threading.Thread(
            target=self.speak_blocking,
            args=(text, rate, on_first_play, on_start, on_end),
            daemon=True,
        ).start()


_GLOBAL_SPEAKER = PipelinedSpeaker()


def get_speaker() -> PipelinedSpeaker:
    return _GLOBAL_SPEAKER

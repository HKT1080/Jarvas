﻿import concurrent.futures
import datetime
import json
import os
import re
import shlex
import subprocess
import sys
import time
import urllib.error
import urllib.request
from typing import Any, Callable, Dict, List, Optional, Tuple

import psutil

from core.ambient_context import capture_screen_b64, get_ambient_monitor, is_deictic_query, read_clipboard_text
from core.live_weather_search import get_live_weather, is_weather_query, robust_web_search
from core.omega_session import get_session_bus
from core.proactive_scheduler import get_scheduler, parse_vietnamese_reminder
from core.secret_dpapi import load_config_decrypted
from core.semantic_memory import get_semantic_memory

DAYS_VN = ["Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy", "Chủ Nhật"]

PERSONA_PROMPTS = {
    "friendly": "xưng 'mình' - gọi người dùng bằng tên '{name}', thân thiện, gần gũi, nhiệt tình và tinh tế.",
    "professional": "xưng 'Jarvis' - gọi người dùng là '{name}', lịch sự, chuyên nghiệp, súc tích và rõ ràng.",
    "bestie": "xưng 'tao' - gọi người dùng là 'mày', vui vẻ, thẳng thắn, tự nhiên như bạn thân.",
}

BUILTIN_LITE_TOOLS = {
    "live_weather", "fast_web_search", "set_reminder", "list_reminders",
    "delete_reminder", "recall_memory", "save_memory", "open_safe", "system_info",
}


def _decode_unicode(s: str) -> str:
    if not s:
        return ""
    s = re.sub(r"\\u([0-9a-fA-F]{4})", lambda m: chr(int(m.group(1), 16)), s)
    return s.replace('\\"', '"').replace("\\n", "\n").replace("\\t", " ").replace("\\\\", "\\").strip()


def _parse_json_safe(raw: str) -> Dict[str, Any]:
    cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw or "", flags=re.S).strip()
    s, e = cleaned.find("{"), cleaned.rfind("}")
    body = cleaned[s : e + 1] if (s != -1 and e > s) else cleaned
    try:
        obj = json.loads(body)
        if isinstance(obj, dict):
            return obj
    except Exception:
        pass
    out: Dict[str, Any] = {}
    m_rep = re.search(r'"reply"\s*:\s*"(.*?)"\s*(?:,\s*"(?:emotion|plan|remember)"|\}\s*$)', body, flags=re.S)
    if m_rep:
        out["reply"] = _decode_unicode(m_rep.group(1))
    else:
        out["reply"] = _decode_unicode(body.strip('"{} \n\r\t'))
    return out


def _open_safe_target(target: str) -> Tuple[str, bool]:
    """Mở an toàn URL, ứng dụng Windows phổ biến, hoặc file cá nhân trong Desktop/Downloads/Documents."""
    t = (target or "").strip().strip('"').strip("'")
    if not t:
        return "Bạn chưa nêu rõ tên ứng dụng, trang web hoặc file cần mở.", True
    if re.match(r"^(https?://|ms-settings:|www\.)", t, flags=re.I):
        url = ("https://" + t) if t.lower().startswith("www.") else t
        os.startfile(url)
        return f"🌐 Đã mở: {url}", False
    if os.path.exists(t):
        os.startfile(t)
        return f"📂 Đã mở: {t}", False

    low = t.lower()
    apps = {
        "notepad": "notepad.exe", "ghi chú": "notepad.exe",
        "calculator": "calc.exe", "máy tính": "calc.exe", "calc": "calc.exe",
        "paint": "mspaint.exe", "explorer": "explorer.exe", "cài đặt": "ms-settings:",
        "chrome": "chrome", "edge": "msedge", "word": "winword", "excel": "excel",
        "powerpoint": "powerpnt", "vscode": "code",
    }
    if low in apps:
        try:
            os.startfile(apps[low])
            return f"🚀 Đã mở ứng dụng {t}!", False
        except Exception:
            pass

    home = os.path.expanduser("~")
    for root_d in (os.path.join(home, "Desktop"), os.path.join(home, "Downloads"), os.path.join(home, "Documents")):
        if not os.path.isdir(root_d):
            continue
        for cur, dirs, files in os.walk(root_d):
            if cur.count(os.sep) - root_d.count(os.sep) > 2:
                dirs[:] = []
                continue
            for fn in files:
                if low in fn.lower():
                    fp = os.path.join(cur, fn)
                    os.startfile(fp)
                    return f"📄 Đã tìm thấy và mở: {fp}", False
    return f"Chưa tìm thấy '{t}' trong các ứng dụng phổ biến hoặc Desktop/Downloads/Documents.", True


class LiteKernel:
    """
    Jarvis Lite v1.0 Kernel — An toàn 100%, nhẹ, nhanh, không chạy code động ngầm.
    Tập trung tối đa vào: Hiểu màn hình & Clipboard + Nhắc việc chủ động + Trí nhớ dài hạn + 12 Tool dân dụng.
    """

    def __init__(self):
        self.sem_mem = get_semantic_memory()
        self.scheduler = get_scheduler()
        self.ambient = get_ambient_monitor()
        self.session = get_session_bus()
        self.pool = concurrent.futures.ThreadPoolExecutor(max_workers=3)

    def load_config(self) -> Dict[str, Any]:
        return load_config_decrypted("config.json")

    def load_features(self) -> Dict[str, Any]:
        try:
            return json.load(open("features.json", "r", encoding="utf-8-sig"))
        except Exception:
            return {"edition": "LITE", "version": "1.0.0", "features": {}}

    def get_model_pair(self) -> Tuple[str, str]:
        vlm = self.load_config().get("vlm", {})
        fast = str(vlm.get("fast_model") or vlm.get("model") or "gemini-2.5-flash").strip()
        pro = str(vlm.get("pro_model") or fast).strip()
        return fast, pro

    def _persona_instruction(self) -> str:
        prof = self.load_config().get("profile", {})
        uname = str(prof.get("user_name") or "bạn").strip()
        pkey = str(prof.get("persona") or "friendly").strip()
        tpl = PERSONA_PROMPTS.get(pkey, PERSONA_PROMPTS["friendly"])
        return tpl.format(name=uname)

    def _load_catalog(self) -> Tuple[Dict[str, str], str]:
        reg = {}
        try:
            reg = json.load(open("tools/registry.json", "r", encoding="utf-8-sig"))
        except Exception:
            pass
        items = [
            "- live_weather: Xem thời tiết hiện tại và dự báo ngày mai chính xác (args: tên thành phố hoặc trống).",
            "- fast_web_search: Tìm kiếm thông tin mới nhất trên Internet (args: từ khóa).",
            "- set_reminder: Đặt lịch hẹn nhắc việc chủ động bằng thông báo + đọc ra loa (args: vd '15 phút nữa nhắc uống nước').",
            "- list_reminders: Xem các lịch nhắc việc đang chờ.",
            "- delete_reminder: Hủy lịch nhắc việc (args: từ khóa hoặc 'all').",
            "- recall_memory: Tìm lại thông tin đã ghi nhớ trước đây (args: từ khóa).",
            "- save_memory: Ghi nhớ thông tin/sở thích quan trọng của người dùng (args: nội dung).",
            "- open_safe: Mở trang web (URL), ứng dụng phổ biến (Chrome, Word, Excel, Notepad...) hoặc file trong Desktop/Downloads/Documents.",
            "- system_info: Xem trạng thái CPU, RAM, pin, Clipboard hiện tại.",
        ]
        for k, v in reg.items():
            items.append(f"- {k}: {str(v)[:115]}")
        return reg, "\n".join(items)

    def _system_context(self, user_text: str) -> str:
        now = datetime.datetime.now()
        date_line = f"{DAYS_VN[now.weekday()]}, ngày {now.day:02d}/{now.month:02d}/{now.year}, lúc {now.hour:02d}:{now.minute:02d}"
        try:
            cpu = psutil.cpu_percent(interval=None)
            ram = psutil.virtual_memory().percent
            bat = psutil.sensors_battery()
            bat_s = f"{bat.percent}% ({'đang sạc' if bat.power_plugged else 'dùng pin'})" if bat else "nguồn trực tiếp"
            hw = f"CPU {cpu}% | RAM {ram}% | Pin {bat_s}"
        except Exception:
            hw = ""
        parts = [
            f"THỜI GIAN HIỆN TẠI: {date_line}",
            f"MÁY TÍNH: {hw}",
            self.ambient.format_for_prompt(include_clipboard=True),
        ]
        rems = self.scheduler.list_pending()
        if rems:
            parts.append("LỊCH NHẮC SẮP TỚI: " + " | ".join(f"[{r['due_str']}] {r['task']}" for r in rems[:4]))
        mem_ctx = self.sem_mem.format_context(user_text, top_k=5)
        if mem_ctx:
            parts.append(mem_ctx)
        return "\n".join(parts)

    def _call_llm(self, messages: List[Dict[str, Any]], heavy: bool = False, max_tokens: int = 1600, temp: float = 0.45) -> Tuple[str, str]:
        vlm = self.load_config().get("vlm", {})
        endpoint = str(vlm.get("endpoint") or "").strip()
        api_key = str(vlm.get("api_key") or "").strip()
        fast_m, pro_m = self.get_model_pair()
        models = [pro_m, fast_m] if (heavy and pro_m != fast_m) else [fast_m]
        headers = {"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"}

        last_err = ""
        for mdl in models:
            try:
                payload = {"model": mdl, "temperature": temp, "max_tokens": max_tokens, "messages": messages}
                req = urllib.request.Request(endpoint, data=json.dumps(payload, ensure_ascii=False).encode("utf-8"), headers=headers, method="POST")
                with urllib.request.urlopen(req, timeout=55) as resp:
                    body = json.loads(resp.read().decode("utf-8"))
                    return body["choices"][0]["message"]["content"].strip(), mdl
            except urllib.error.HTTPError as e:
                last_err = f"HTTP {e.code}: {e.read().decode('utf-8', errors='ignore')[:200]}"
            except Exception as e:
                last_err = str(e)
        raise RuntimeError(f"Lỗi kết nối AI: {last_err}")

    def _exec_tool(self, tool_name: str, args: str, reg: Dict[str, str]) -> Tuple[str, bool]:
        t, a = (tool_name or "").strip(), (args or "").strip()
        if t == "live_weather":
            out = get_live_weather(a)
            return out, ("Không kết nối" in out)
        if t == "fast_web_search":
            return robust_web_search(a, max_results=5), False
        if t == "set_reminder":
            item = self.scheduler.add_from_text(a if any(k in a.lower() for k in ("nhắc", "hẹn", "báo")) else f"nhắc tao {a}")
            return (f"⏰ Đã đặt lịch nhắc: '{item['task']}' lúc {item['due_str']}.", False) if item else ("Chưa rõ mốc giờ cần hẹn.", True)
        if t == "list_reminders":
            items = self.scheduler.list_pending()
            return ("\n".join(f"- [{r['id']}] {r['due_str']}: {r['task']}" for r in items), False) if items else ("Hiện chưa có lịch nhắc nào.", False)
        if t == "delete_reminder":
            n = self.scheduler.delete(a or "all")
            return f"Đã hủy {n} lịch nhắc.", (n == 0)
        if t == "recall_memory":
            found = self.sem_mem.recall(a, top_k=5)
            return ("\n".join(f"- [{x['updated_at']}] {x['content']}" for x in found), False) if found else ("Chưa thấy ký ức liên quan.", False)
        if t == "save_memory":
            st, _ = self.sem_mem.upsert_fact(a, category="user_note", importance=0.9)
            return f"🧬 Đã lưu ghi nhớ ({st}): {a}", False
        if t == "open_safe":
            return _open_safe_target(a)
        if t == "system_info":
            cpu = psutil.cpu_percent(interval=0.2)
            ram = psutil.virtual_memory().percent
            clip = read_clipboard_text(300)
            return f"💻 CPU: {cpu}% | RAM: {ram}% | Clipboard: {clip or '(trống)'}", False

        t_file = os.path.join("tools", f"{t}.py")
        if t not in reg or not os.path.isfile(t_file):
            return f"Tính năng '{t}' không nằm trong gói Jarvis Lite v1.0.", True
        cli_args = shlex.split(a) if (a and (a.startswith("-") or " --" in a)) else ([a] if a else [])
        env = os.environ.copy()
        env["PYTHONIOENCODING"] = "utf-8"
        env["PYTHONUTF8"] = "1"
        try:
            r = subprocess.run([sys.executable, t_file] + cli_args, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=45, creationflags=0x08000000, env=env)
            out = (r.stdout or "").strip()
            err = (r.stderr or "").strip()
            return (out or err or "Đã thực thi xong!"), (r.returncode != 0)
        except Exception as e:
            return f"Lỗi chạy {t}: {e}", True

    def handle(self, text: str, source: str = "lite_ui", attached_image_b64: Optional[str] = None, on_event: Optional[Callable[[Dict[str, Any]], None]] = None) -> Dict[str, Any]:
        t0 = time.perf_counter()
        user_text = (text or "").strip()
        steps_log: List[str] = []
        fast_m, _ = self.get_model_pair()

        def _emit(kind: str, msg: str):
            steps_log.append(msg)
            if on_event:
                try:
                    on_event({"type": kind, "message": msg, "ts": time.time()})
                except Exception:
                    pass

        def _done(reply: str, route: str, mdl: str) -> Dict[str, Any]:
            rep = _decode_unicode(reply) or "Mình xử lý xong rồi!"
            if user_text:
                self.session.append_turn(source, user_text, rep, meta={"route": route, "model": mdl})
            return {
                "ok": True, "source": source, "route": route, "model_used": mdl,
                "reply": rep, "spoken": rep[:600], "steps_log": steps_log,
                "elapsed_ms": int((time.perf_counter() - t0) * 1000),
            }

        if not user_text:
            return _done("Bạn hãy nhập yêu cầu hoặc bấm nút Mic để nói nhé!", "EMPTY", fast_m)

        # 1. Hẹn nhắc nhanh
        rem = parse_vietnamese_reminder(user_text)
        if rem:
            item = self.scheduler.add(rem["task"], rem["due_ts"])
            _emit("tool", f"⏰ Đã hẹn nhắc lúc {item['due_str']}: {item['task']}")
            return _done(f"⏰ Đã chốt lịch nhắc! Đúng **{item['due_str']}** Jarvis sẽ hiện thông báo và đọc nhắc: *{item['task']}*.", "REMINDER", "local")

        # 2. Thời tiết nhanh
        if is_weather_query(user_text) and len(user_text) <= 85:
            _emit("tool", "🌤️ Đang tra cứu thời tiết trực tiếp...")
            w_out = get_live_weather(user_text)
            raw, mdl = self._call_llm([
                {"role": "system", "content": f"Bạn là Jarvis Lite ({self._persona_instruction()}). Trả lời gọn, đầy đủ số liệu thời tiết."},
                {"role": "user", "content": f"Câu hỏi: {user_text}\nDữ liệu thời tiết:\n{w_out}"},
            ], heavy=False, max_tokens=500)
            return _done(raw or w_out, "WEATHER", mdl)

        screen_b64 = None
        if is_deictic_query(user_text):
            _emit("context", "👁️ Đang quan sát cửa sổ hiện tại & Clipboard để hiểu đúng ngữ cảnh...")
            screen_b64 = capture_screen_b64(max_width=1024, quality=68)

        reg, catalog = self._load_catalog()
        sys_ctx = self._system_context(user_text)
        heavy = len(user_text) >= 120 or any(k in user_text.lower() for k in ("so sánh", "phân tích", "lập kế hoạch", "viết code", "sửa lỗi", "giải thích sâu"))
        _emit("route", f"🧠 Đang suy nghĩ ({'Pro' if heavy else 'Fast'})...")

        sys_prompt = (
            f"Bạn là JARVIS LITE v1.0 — Trợ lý AI thông minh trên Windows ({self._persona_instruction()}).\n\n"
            f"{sys_ctx}\n\n"
            "NGUYÊN TẮC:\n"
            "1. Tận dụng CỬA SỔ ĐANG LÀM VIỆC, CLIPBOARD và hình ảnh đính kèm (nếu có) để hiểu ý ngay không cần hỏi lại.\n"
            "2. Nếu cần dùng công cụ trong danh sách bên dưới, điền vào mảng `plan` (tối đa 3 bước `{\"tool\": \"...\", \"args\": \"...\"}`).\n"
            "3. Nếu không cần công cụ, để `\"plan\": []` và trả lời thật có tâm, mạch lạc (có thể dùng Markdown in đậm, bảng biểu, khối code).\n"
            "4. Nếu người dùng tiết lộ sở thích/thông tin cá nhân mới -> ghi 1 câu ngắn vào `remember`.\n"
            "5. Nếu người dùng đòi tính năng nâng cao chưa mở ở bản Lite (như tự điều khiển chuột/phím OS Agent, nhận diện khuôn mặt 3D, cử chỉ tay, tự viết tool hệ thống) -> giải thích lịch sự rằng tính năng đó nằm trong lộ trình bản cập nhật sắp tới / Jarvis Pro.\n\n"
            f"CÔNG CỤ KHẢ DỤNG:\n{catalog}\n\n"
            'CHỈ trả về JSON hợp lệ UTF-8 (KHÔNG dùng dấu " bên trong chuỗi, thay bằng nháy đơn \'):\n'
            '{"plan": [{"tool": "", "args": ""}], "remember": "", "reply": "câu trả lời"}'
        )

        msgs: List[Dict[str, Any]] = [{"role": "system", "content": sys_prompt}]
        msgs.extend(self.session.get_llm_messages(limit=8))

        if attached_image_b64 or screen_b64:
            parts: List[Dict[str, Any]] = [{"type": "text", "text": user_text}]
            if attached_image_b64:
                parts.append({"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{attached_image_b64}"}})
            if screen_b64:
                parts.append({"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{screen_b64}"}})
            msgs.append({"role": "user", "content": parts})
        else:
            msgs.append({"role": "user", "content": user_text})

        raw1, mdl = self._call_llm(msgs, heavy=heavy, max_tokens=1600)
        p1 = _parse_json_safe(raw1)

        if p1.get("remember"):
            self.sem_mem.upsert_fact(str(p1["remember"]), category="profile", importance=0.85)
            _emit("memory", f"🧬 Đã ghi nhớ: {p1['remember']}")

        plan = [st for st in (p1.get("plan") or [])[:3] if isinstance(st, dict) and st.get("tool") in (set(reg.keys()) | BUILTIN_LITE_TOOLS)]
        if not plan:
            return _done(str(p1.get("reply") or raw1), "LITE_CHAT", mdl)

        _emit("tool", "⚡ Đang chạy công cụ: " + ", ".join(st["tool"] for st in plan))
        futs = [self.pool.submit(self._exec_tool, st["tool"], str(st.get("args") or ""), reg) for st in plan]
        results = []
        for st, f in zip(plan, futs):
            out, err = f.result(timeout=55)
            results.append({"tool": st["tool"], "output": out[:2200], "error": err})

        if len(results) == 1 and not results[0]["error"] and results[0]["tool"] in ("open_safe", "set_reminder", "delete_reminder", "save_memory"):
            return _done(results[0]["output"], "LITE_TOOL", mdl)

        dump = "\n".join(f"- {r['tool']}: {r['output']}" for r in results)
        _emit("synth", "✨ Đang tổng hợp câu trả lời...")
        final_txt, mdl = self._call_llm([
            {"role": "system", "content": f"Bạn là Jarvis Lite ({self._persona_instruction()}). Tổng hợp kết quả công cụ dưới đây thành câu trả lời tự nhiên, dễ đọc (có thể dùng Markdown gọn đẹp)."},
            {"role": "user", "content": f"Yêu cầu: {user_text}\n\nKết quả công cụ:\n{dump}"},
        ], heavy=heavy, max_tokens=1500)
        return _done(final_txt, "LITE_AGENT", mdl)


_LITE_KERNEL = LiteKernel()


def get_lite_kernel() -> LiteKernel:
    return _LITE_KERNEL

import base64
import ctypes
from ctypes import wintypes
import json
import os
from typing import Any, Tuple

DPAPI_PREFIX = "DPAPI:"
_ENTROPY = b"JARVIS_OMEGA_SECRETS_DPAPI_V1"
CRYPTPROTECT_UI_FORBIDDEN = 0x01


class _DATA_BLOB(ctypes.Structure):
    _fields_ = [
        ("cbData", wintypes.DWORD),
        ("pbData", ctypes.POINTER(ctypes.c_char)),
    ]


_crypt32 = ctypes.WinDLL("crypt32", use_last_error=True)
_kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

_crypt32.CryptProtectData.argtypes = [
    ctypes.POINTER(_DATA_BLOB), wintypes.LPCWSTR,
    ctypes.POINTER(_DATA_BLOB), ctypes.c_void_p, ctypes.c_void_p,
    wintypes.DWORD, ctypes.POINTER(_DATA_BLOB),
]
_crypt32.CryptProtectData.restype = wintypes.BOOL

_crypt32.CryptUnprotectData.argtypes = [
    ctypes.POINTER(_DATA_BLOB), ctypes.POINTER(wintypes.LPWSTR),
    ctypes.POINTER(_DATA_BLOB), ctypes.c_void_p, ctypes.c_void_p,
    wintypes.DWORD, ctypes.POINTER(_DATA_BLOB),
]
_crypt32.CryptUnprotectData.restype = wintypes.BOOL

_kernel32.LocalFree.argtypes = [ctypes.c_void_p]
_kernel32.LocalFree.restype = ctypes.c_void_p


def _to_blob(raw: bytes):
    buf = ctypes.create_string_buffer(raw, len(raw))
    blob = _DATA_BLOB(len(raw), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char)))
    return blob, buf


def protect_bytes(raw: bytes) -> bytes:
    in_b, _b1 = _to_blob(raw)
    ent_b, _b2 = _to_blob(_ENTROPY)
    out_b = _DATA_BLOB()
    ok = _crypt32.CryptProtectData(
        ctypes.byref(in_b), "JarvisOmegaSecret",
        ctypes.byref(ent_b), None, None,
        CRYPTPROTECT_UI_FORBIDDEN, ctypes.byref(out_b),
    )
    if not ok:
        raise RuntimeError("Windows DPAPI CryptProtectData that bai")
    try:
        return ctypes.string_at(out_b.pbData, out_b.cbData)
    finally:
        _kernel32.LocalFree(out_b.pbData)


def unprotect_bytes(enc: bytes) -> bytes:
    in_b, _b1 = _to_blob(enc)
    ent_b, _b2 = _to_blob(_ENTROPY)
    out_b = _DATA_BLOB()
    ok = _crypt32.CryptUnprotectData(
        ctypes.byref(in_b), None,
        ctypes.byref(ent_b), None, None,
        CRYPTPROTECT_UI_FORBIDDEN, ctypes.byref(out_b),
    )
    if not ok:
        raise RuntimeError("Windows DPAPI CryptUnprotectData that bai (sai may/tai khoan)")
    try:
        return ctypes.string_at(out_b.pbData, out_b.cbData)
    finally:
        _kernel32.LocalFree(out_b.pbData)


def is_protected(val: Any) -> bool:
    return isinstance(val, str) and val.startswith(DPAPI_PREFIX)


def protect_str(plain: str) -> str:
    s = str(plain or "").strip()
    if not s or s.startswith(DPAPI_PREFIX):
        return s
    enc = protect_bytes(s.encode("utf-8"))
    return DPAPI_PREFIX + base64.b64encode(enc).decode("ascii")


def unprotect_str(val: Any) -> str:
    s = str(val or "").strip()
    if not s:
        return ""
    if not s.startswith(DPAPI_PREFIX):
        return s
    try:
        raw = base64.b64decode(s[len(DPAPI_PREFIX):].encode("ascii"))
        return unprotect_bytes(raw).decode("utf-8")
    except Exception as _e:
        try:
            os.makedirs("logs", exist_ok=True)
            with open(os.path.join("logs", "dpapi_error.log"), "a", encoding="utf-8") as _lf:
                _lf.write(f"unprotect_str error: {type(_e).__name__}: {_e}\n")
        except Exception:
            pass
        return ""


def load_config_decrypted(path: str = "config.json") -> dict:
    try:
        cfg = json.load(open(path, "r", encoding="utf-8-sig"))
    except Exception:
        return {}
    vlm = cfg.get("vlm")
    if isinstance(vlm, dict) and vlm.get("api_key"):
        vlm["api_key"] = unprotect_str(vlm["api_key"])
    return cfg


def load_telegram_decrypted(path: str = "telegram_config.json") -> Tuple[str | None, Any]:
    if not os.path.exists(path):
        return None, None
    try:
        cfg = json.load(open(path, "r", encoding="utf-8-sig"))
        tok = unprotect_str(cfg.get("token") or cfg.get("bot_token") or "")
        cid = cfg.get("chat_id") or cfg.get("allowed_chat_id")
        return (tok or None), cid
    except Exception:
        return None, None


def seal_config_and_telegram(cfg_path: str = "config.json", tg_path: str = "telegram_config.json") -> dict:
    """Tự động mã hóa API Key & Telegram Token trên đĩa sang chuẩn DPAPI."""
    report = {"config_sealed": False, "telegram_sealed": False}

    if os.path.exists(cfg_path):
        cfg = json.load(open(cfg_path, "r", encoding="utf-8-sig"))
        vlm = cfg.get("vlm")
        if isinstance(vlm, dict):
            raw_k = str(vlm.get("api_key") or "").strip()
            if raw_k and not is_protected(raw_k) and not raw_k.startswith("***"):
                vlm["api_key"] = protect_str(raw_k)
                with open(cfg_path, "w", encoding="utf-8") as f:
                    json.dump(cfg, f, ensure_ascii=False, indent=2)
                report["config_sealed"] = True
            elif is_protected(raw_k):
                report["config_sealed"] = True

    if os.path.exists(tg_path):
        tcfg = json.load(open(tg_path, "r", encoding="utf-8-sig"))
        changed = False
        for k in ("token", "bot_token"):
            val = str(tcfg.get(k) or "").strip()
            if val and "DAN_TOKEN" not in val and not is_protected(val):
                tcfg[k] = protect_str(val)
                changed = True
        if changed:
            with open(tg_path, "w", encoding="utf-8") as f:
                json.dump(tcfg, f, ensure_ascii=False, indent=2)
        tok_now = str(tcfg.get("token") or tcfg.get("bot_token") or "")
        report["telegram_sealed"] = is_protected(tok_now)

    return report

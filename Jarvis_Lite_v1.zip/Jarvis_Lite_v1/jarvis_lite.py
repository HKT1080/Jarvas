﻿import os
import sys
import threading
import tkinter as tk

from PIL import Image, ImageDraw
import pystray
from pynput import keyboard

from core.ambient_context import get_ambient_monitor
from core.fast_tts import get_speaker
from core.lite_ui_server import ensure_lite_server, open_lite_window
from core.onboarding import has_valid_api_key, run_onboarding_wizard
from core.proactive_scheduler import get_scheduler


def main():
    if not has_valid_api_key():
        if not run_onboarding_wizard():
            sys.exit(0)

    # Khởi chạy ẩn Tkinter root để hiển thị thông báo nhắc việc nổi (Popup)
    root = tk.Tk()
    root.withdraw()

    class _PopupHost:
        def __init__(self, r):
            self.root = r

    get_ambient_monitor().start()
    get_scheduler().start(hud=_PopupHost(root))
    ensure_lite_server()

    # Phím tắt toàn cục: Ctrl+Alt+J mở Jarvis Lite, Ctrl+Alt+S ngắt giọng đọc
    hk = keyboard.GlobalHotKeys({
        "<ctrl>+<alt>+j": open_lite_window,
        "<ctrl>+<alt>+s": lambda: get_speaker().stop(),
    })
    hk.daemon = True
    hk.start()

    # Khay hệ thống (System Tray)
    def _run_tray():
        img = Image.new("RGB", (64, 64), "#060b16")
        dr = ImageDraw.Draw(img)
        dr.ellipse((8, 8, 56, 56), fill="#00f5d4", outline="#ffffff", width=3)
        dr.ellipse((22, 22, 42, 42), fill="#060b16")
        menu = pystray.Menu(
            pystray.MenuItem("🌌 Mở Jarvis Lite (Ctrl+Alt+J)", lambda _i, _m: open_lite_window()),
            pystray.MenuItem("🔇 Ngắt giọng đọc (Ctrl+Alt+S)", lambda _i, _m: get_speaker().stop()),
            pystray.MenuItem("⚙️ Đổi API Key / Cài đặt lại", lambda _i, _m: root.after(0, run_onboarding_wizard)),
            pystray.MenuItem("✖ Thoát Jarvis Lite", lambda _i, _m: os._exit(0)),
        )
        pystray.Icon("JarvisLite", img, "Jarvis Lite v1.0", menu).run()

    threading.Thread(target=_run_tray, daemon=True).start()
    open_lite_window()
    root.mainloop()


if __name__ == "__main__":
    main()
